//! Chronicle Ledger State Definitions
//!
//! Minimal on-chain state - most data is stored in memos as "virtual PDAs"

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::pubkey::Pubkey;

/// Account discriminators (8 bytes each, matching Anchor convention for compatibility)
pub mod discriminator {
    /// DAO Registry discriminator: sha256("account:DaoRegistry")[..8]
    pub const DAO_REGISTRY: [u8; 8] = [0xC4, 0x12, 0xDA, 0x0F, 0x21, 0x8A, 0xB7, 0x33];
    
    /// Event Anchor discriminator: sha256("account:EventAnchor")[..8]
    pub const EVENT_ANCHOR: [u8; 8] = [0xE7, 0x1A, 0x4C, 0xF9, 0x82, 0x5D, 0x6B, 0x01];
}

/// Minimal DAO Registry - only stores the merkle root and event count
/// 
/// Size: 8 (discriminator) + 32 (dao_key) + 32 (authority) + 32 (merkle_root) 
///       + 8 (event_count) + 8 (last_anchor_slot) + 1 (bump) + 7 (padding) 
///       + 256 (bloom_filter) = 384 bytes
/// Rent: ~0.00267 SOL (still much cheaper than Realms)
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct DaoRegistry {
    /// Account discriminator
    pub discriminator: [u8; 8],
    /// The DAO's unique identifier (usually the council mint or treasury)
    pub dao_key: Pubkey,
    /// Authority that can anchor new merkle roots
    pub authority: Pubkey,
    /// Current merkle root of all events
    pub merkle_root: [u8; 32],
    /// Total number of events anchored
    pub event_count: u64,
    /// Slot when last anchor occurred
    pub last_anchor_slot: u64,
    /// PDA bump seed
    pub bump: u8,
    /// Reserved for future use
    pub _padding: [u8; 7],
    /// Bloom filter for O(1) existence checks (proposals, votes, accounts)
    pub bloom_filter: [u8; 256],
}

impl DaoRegistry {
    /// Account size in bytes
    pub const SIZE: usize = 384;
    
    /// Seeds for PDA derivation: ["dao_registry", dao_key]
    pub fn seeds<'a>(dao_key: &'a Pubkey) -> [&'a [u8]; 2] {
        [b"dao_registry", dao_key.as_ref()]
    }
    
    /// Derive the PDA address
    pub fn find_address(program_id: &Pubkey, dao_key: &Pubkey) -> (Pubkey, u8) {
        Pubkey::find_program_address(&[b"dao_registry", dao_key.as_ref()], program_id)
    }
}

/// Event types supported by Chronicle
/// Not used with Borsh - we use u8 directly for compatibility
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum EventType {
    /// DAO created
    DaoCreate = 0,
    /// Proposal created
    ProposalCreate = 1,
    /// Vote cast
    VoteCast = 2,
    /// Sealed/private vote cast
    SealedVoteCast = 3,
    /// Proposal finalized
    ProposalFinalize = 4,
    /// DAO policy update
    PolicyUpdate = 5,
    /// Council member change
    CouncilChange = 6,
    /// Custom event
    Custom = 255,
}

impl EventType {
    /// Convert to u8
    pub fn to_u8(self) -> u8 {
        self as u8
    }
    
    /// Convert from u8
    pub fn from_u8(v: u8) -> Option<Self> {
        match v {
            0 => Some(Self::DaoCreate),
            1 => Some(Self::ProposalCreate),
            2 => Some(Self::VoteCast),
            3 => Some(Self::SealedVoteCast),
            4 => Some(Self::ProposalFinalize),
            5 => Some(Self::PolicyUpdate),
            6 => Some(Self::CouncilChange),
            255 => Some(Self::Custom),
            _ => None,
        }
    }
}

/// Virtual PDA Event Header - stored in memo, not in an account
/// 
/// This is the structure that would be in a PDA, but we store it in a memo instead.
/// The "address" is derived the same way as a PDA for verification.
#[derive(Debug, Clone)]
pub struct VirtualEvent {
    /// Event type (as u8 for serialization)
    pub event_type: u8,
    /// DAO this event belongs to
    pub dao_key: Pubkey,
    /// Actor who created this event
    pub actor: Pubkey,
    /// Unix timestamp (seconds)
    pub timestamp: i64,
    /// Nonce for uniqueness (prevents replay)
    pub nonce: u64,
    /// Hash of the full event payload (stored off-chain or in separate memo chunks)
    pub payload_hash: [u8; 32],
}

impl VirtualEvent {
    /// Compute the "virtual PDA" address for this event
    /// This matches real PDA derivation but the account doesn't exist
    pub fn virtual_address(&self, program_id: &Pubkey) -> Pubkey {
        let seeds: &[&[u8]] = &[
            b"event",
            self.dao_key.as_ref(),
            &self.nonce.to_le_bytes(),
        ];
        let (address, _bump) = Pubkey::find_program_address(seeds, program_id);
        address
    }
    
    /// Compute the leaf hash for merkle tree
    pub fn leaf_hash(&self) -> [u8; 32] {
        use solana_program::hash::hashv;
        // Manual serialization since we don't derive Borsh
        let mut data = Vec::with_capacity(128);
        data.push(self.event_type);
        data.extend_from_slice(self.dao_key.as_ref());
        data.extend_from_slice(self.actor.as_ref());
        data.extend_from_slice(&self.timestamp.to_le_bytes());
        data.extend_from_slice(&self.nonce.to_le_bytes());
        data.extend_from_slice(&self.payload_hash);
        hashv(&[b"chronicle_event", &data]).to_bytes()
    }
}

/// Compact vote record - what would be a VoteRecord PDA in traditional systems
#[derive(Debug, Clone)]
pub struct VirtualVote {
    /// Proposal this vote is for (virtual address)
    pub proposal: Pubkey,
    /// Voter's wallet
    pub voter: Pubkey,
    /// Vote choice (0=No, 1=Yes, 2=Abstain, 3=Veto)
    pub choice: u8,
    /// Vote weight (token balance at snapshot)
    pub weight: u64,
    /// Unix timestamp
    pub timestamp: i64,
    /// Optional: encrypted choice for sealed voting (base64 in memo)
    pub sealed: bool,
}

impl VirtualVote {
    /// Compute leaf hash for merkle tree
    pub fn leaf_hash(&self) -> [u8; 32] {
        use solana_program::hash::hashv;
        let mut data = Vec::with_capacity(128);
        data.extend_from_slice(self.proposal.as_ref());
        data.extend_from_slice(self.voter.as_ref());
        data.push(self.choice);
        data.extend_from_slice(&self.weight.to_le_bytes());
        data.extend_from_slice(&self.timestamp.to_le_bytes());
        data.push(if self.sealed { 1 } else { 0 });
        hashv(&[b"chronicle_vote", &data]).to_bytes()
    }
    
    /// Compute the "double-vote prevention" key
    /// This is used to check if a voter already voted on a proposal
    pub fn vote_key(&self) -> [u8; 32] {
        use solana_program::hash::hashv;
        hashv(&[
            b"vote_key",
            self.proposal.as_ref(),
            self.voter.as_ref(),
        ]).to_bytes()
    }
}

/// Minimal Event Anchor - optionally created for critical events that need
/// guaranteed on-chain presence (like finalization with execution hash)
/// 
/// Size: 8 + 32 + 32 + 8 + 1 + 7 = 88 bytes (~0.00067 SOL rent)
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct EventAnchor {
    /// Discriminator
    pub discriminator: [u8; 8],
    /// Reference to the event (virtual address or hash)
    pub event_ref: [u8; 32],
    /// The DAO this belongs to
    pub dao_key: Pubkey,
    /// Slot when anchored
    pub slot: u64,
    /// Bump seed
    pub bump: u8,
    /// Padding
    pub _padding: [u8; 7],
}

impl EventAnchor {
    /// Account size
    pub const SIZE: usize = 88;
    
    /// Find PDA address
    pub fn find_address(program_id: &Pubkey, dao_key: &Pubkey, event_ref: &[u8; 32]) -> (Pubkey, u8) {
        Pubkey::find_program_address(
            &[b"event_anchor", dao_key.as_ref(), event_ref],
            program_id,
        )
    }
}

/// Data Anchor - for storing large data on-chain permanently
/// 
/// This is Chronicle's custom memo alternative that supports:
/// - Larger payloads (up to 10KB per account)
/// - Chunked storage for very large data
/// - Structured indexing by data type and entity
/// 
/// Size: 8 + 1 + 32 + 32 + 4 + 2 + 1 + 8 + 1 + 7 + data = 96 + data bytes
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct DataAnchor {
    /// Discriminator: "CHRDATA\0"
    pub discriminator: [u8; 8],
    /// Data type (proposal, vote, census, etc.)
    pub data_type: u8,
    /// Entity ID (proposal_id, etc.)
    pub entity_id: [u8; 32],
    /// Full data hash (SHA256)
    pub data_hash: [u8; 32],
    /// Total data size
    pub total_size: u32,
    /// Chunk count (1 = complete, >1 = chunked)
    pub chunk_count: u16,
    /// Is data complete?
    pub is_complete: bool,
    /// Timestamp
    pub timestamp: i64,
    /// Bump seed
    pub bump: u8,
    /// Padding
    pub _padding: [u8; 6],
    /// Actual data (variable length)
    pub data: Vec<u8>,
}

impl DataAnchor {
    /// Header size (before data)
    pub const HEADER_SIZE: usize = 96;
    
    /// Maximum data per account (~10KB practical limit)
    pub const MAX_DATA_SIZE: usize = 10_000;
    
    /// Discriminator value
    pub const DISCRIMINATOR: [u8; 8] = [0x43, 0x48, 0x52, 0x44, 0x41, 0x54, 0x41, 0x00]; // "CHRDATA\0"
    
    /// Find PDA address
    pub fn find_address(program_id: &Pubkey, dao_key: &Pubkey, entity_id: &[u8; 32]) -> (Pubkey, u8) {
        Pubkey::find_program_address(
            &[b"data_anchor", dao_key.as_ref(), entity_id],
            program_id,
        )
    }
    
    /// Calculate account size for given data length
    pub fn account_size(data_len: usize) -> usize {
        Self::HEADER_SIZE + data_len
    }
}
