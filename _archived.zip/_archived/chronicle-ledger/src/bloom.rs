//! Chronicle Bloom Filter Implementation
//! 
//! Provides O(1) probabilistic set membership checks for:
//! - Double-vote prevention
//! - Duplicate proposal detection
//! - Member existence checks
//!
//! False positive rate ~1% with 4 hash functions and 4096 bits (512 bytes)

use solana_program::hash::hashv;

/// Bloom filter configuration
/// Using 256 bytes (2048 bits) to match DaoRegistry.bloom_filter size
pub const BLOOM_BITS: usize = 2048;  // 256 bytes
pub const BLOOM_BYTES: usize = BLOOM_BITS / 8;
pub const NUM_HASHES: usize = 4;

/// Check if an item is probably in the bloom filter
/// Returns false if definitely not present, true if probably present
pub fn bloom_check(bloom: &[u8], key: &[u8]) -> bool {
    let hash = hashv(&[key]).to_bytes();
    
    for i in 0..NUM_HASHES {
        let bit_index = u16::from_le_bytes([hash[i * 2], hash[i * 2 + 1]]) as usize % BLOOM_BITS;
        let byte_index = bit_index / 8;
        let bit_offset = bit_index % 8;
        
        if byte_index >= bloom.len() {
            return false;
        }
        
        if bloom[byte_index] & (1 << bit_offset) == 0 {
            return false;  // Definitely not present
        }
    }
    
    true  // Probably present
}

/// Add an item to the bloom filter
pub fn bloom_add(bloom: &mut [u8], key: &[u8]) {
    let hash = hashv(&[key]).to_bytes();
    
    for i in 0..NUM_HASHES {
        let bit_index = u16::from_le_bytes([hash[i * 2], hash[i * 2 + 1]]) as usize % BLOOM_BITS;
        let byte_index = bit_index / 8;
        let bit_offset = bit_index % 8;
        
        if byte_index < bloom.len() {
            bloom[byte_index] |= 1 << bit_offset;
        }
    }
}

/// Create a vote key for bloom filter (proposal + voter)
pub fn vote_bloom_key(proposal_id: &[u8; 32], voter: &[u8; 32]) -> [u8; 32] {
    hashv(&[b"vote_bloom", proposal_id, voter]).to_bytes()
}

/// Create a proposal key for bloom filter
pub fn proposal_bloom_key(proposal_id: &[u8; 32]) -> [u8; 32] {
    hashv(&[b"proposal_bloom", proposal_id]).to_bytes()
}

/// Create a member key for bloom filter
pub fn member_bloom_key(member: &[u8; 32]) -> [u8; 32] {
    hashv(&[b"member_bloom", member]).to_bytes()
}

/// Check if a voter has likely voted on a proposal
pub fn check_vote_exists(bloom: &[u8], proposal_id: &[u8; 32], voter: &[u8; 32]) -> bool {
    let key = vote_bloom_key(proposal_id, voter);
    bloom_check(bloom, &key)
}

/// Add a vote to the bloom filter
pub fn add_vote_to_bloom(bloom: &mut [u8], proposal_id: &[u8; 32], voter: &[u8; 32]) {
    let key = vote_bloom_key(proposal_id, voter);
    bloom_add(bloom, &key);
}

/// Check if a proposal likely exists
pub fn check_proposal_exists(bloom: &[u8], proposal_id: &[u8; 32]) -> bool {
    let key = proposal_bloom_key(proposal_id);
    bloom_check(bloom, &key)
}

/// Add a proposal to the bloom filter
pub fn add_proposal_to_bloom(bloom: &mut [u8], proposal_id: &[u8; 32]) {
    let key = proposal_bloom_key(proposal_id);
    bloom_add(bloom, &key);
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_bloom_add_check() {
        let mut bloom = [0u8; BLOOM_BYTES];
        
        let key1 = b"test_key_1";
        let key2 = b"test_key_2";
        let key3 = b"test_key_3";
        
        // Initially empty
        assert!(!bloom_check(&bloom, key1));
        assert!(!bloom_check(&bloom, key2));
        
        // Add key1
        bloom_add(&mut bloom, key1);
        assert!(bloom_check(&bloom, key1));
        assert!(!bloom_check(&bloom, key2));  // key2 still not present
        
        // Add key2
        bloom_add(&mut bloom, key2);
        assert!(bloom_check(&bloom, key1));
        assert!(bloom_check(&bloom, key2));
        assert!(!bloom_check(&bloom, key3));  // key3 still not present
    }
    
    #[test]
    fn test_vote_bloom() {
        let mut bloom = [0u8; BLOOM_BYTES];
        
        let proposal1 = [1u8; 32];
        let proposal2 = [2u8; 32];
        let voter1 = [10u8; 32];
        let voter2 = [20u8; 32];
        
        // No votes initially
        assert!(!check_vote_exists(&bloom, &proposal1, &voter1));
        
        // Add vote
        add_vote_to_bloom(&mut bloom, &proposal1, &voter1);
        
        // Check exists
        assert!(check_vote_exists(&bloom, &proposal1, &voter1));
        
        // Different voter on same proposal - not present
        assert!(!check_vote_exists(&bloom, &proposal1, &voter2));
        
        // Same voter on different proposal - not present
        assert!(!check_vote_exists(&bloom, &proposal2, &voter1));
    }
}
