//! Chronicle State Tree - Fully On-Chain Virtual PDA System
//!
//! This module implements a revolutionary "Aggregated State Tree" pattern that
//! provides Virtual PDA functionality WITHOUT requiring any off-chain database.
//!
//! ## The Innovation
//!
//! Traditional PDAs: 1 account per record = expensive (rent for each)
//! Virtual PDAs v1:  Data in memos + off-chain indexer = centralized
//! Virtual PDAs v2:  Aggregated State Tree = fully on-chain, decentralized
//!
//! ## How It Works
//!
//! 1. **State Root Account**: A single PDA per DAO stores:
//!    - Merkle root of all events
//!    - Aggregated vote tallies
//!    - Active proposal bitmap
//!    - Census results (compressed)
//!
//! 2. **Event Logging**: Each action (vote, proposal, etc.) is:
//!    - Written to a Memo instruction (permanent on-chain log)
//!    - State Root is atomically updated with new merkle root
//!    - Current tallies/state updated in the State Root account
//!
//! 3. **Reading State**: No database needed!
//!    - Current state: Read State Root account directly
//!    - Historical data: Query transaction logs via RPC (decentralized)
//!    - Verification: Merkle proofs against on-chain root
//!
//! ## Cost Model
//!
//! Per DAO: ~0.002 SOL (one-time, State Root account rent)
//! Per Vote: ~0.000005 SOL (transaction fee only!)
//! Per Proposal: ~0.000005 SOL (transaction fee only!)
//!
//! No per-record PDAs = massive cost savings while staying 100% on-chain.

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::pubkey::Pubkey;

/// Maximum proposals that can be active simultaneously (bitmap)
pub const MAX_ACTIVE_PROPOSALS: usize = 256;

/// Maximum options per proposal for census
pub const MAX_OPTIONS: usize = 16;

/// State Root Account - The "database" for a DAO, fully on-chain
/// 
/// This single account stores all aggregated state, eliminating the need
/// for individual PDAs per vote/proposal while remaining fully on-chain.
///
/// Size: 8 + 32 + 32 + 8 + 8 + 8 + 32 + (256 * 40) + 256 + 64 = ~10.5KB
/// Rent: ~0.075 SOL per DAO (one-time, covers unlimited votes!)
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct StateRoot {
    /// Account discriminator
    pub discriminator: [u8; 8],
    
    /// DAO identifier (council mint, treasury, etc.)
    pub dao_key: Pubkey,
    
    /// Authority that can modify DAO settings
    pub authority: Pubkey,
    
    /// Total events ever recorded
    pub event_count: u64,
    
    /// Current proposal counter (for generating IDs)
    pub proposal_counter: u64,
    
    /// Slot of last state update
    pub last_update_slot: u64,
    
    /// Merkle root of all events (for historical verification)
    pub merkle_root: [u8; 32],
    
    /// Active proposal tallies (up to 256 concurrent proposals)
    /// Each entry: [proposal_id: u64, yes: u64, no: u64, abstain: u64, status: u8, padding: 7]
    pub proposal_tallies: Vec<ProposalTally>,
    
    /// Bitmap of active proposal slots
    pub active_bitmap: [u8; 32],
    
    /// PDA bump
    pub bump: u8,
    
    /// DAO configuration
    pub config: DaoConfig,
}

/// Compact proposal tally stored in State Root
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone, Default)]
pub struct ProposalTally {
    /// Proposal ID (sequential)
    pub proposal_id: u64,
    /// Total YES votes (weighted)
    pub yes_votes: u64,
    /// Total NO votes (weighted)  
    pub no_votes: u64,
    /// Total ABSTAIN votes (weighted)
    pub abstain_votes: u64,
    /// Total unique voters
    pub voter_count: u32,
    /// Proposal status: 0=Draft, 1=Active, 2=Passed, 3=Rejected, 4=Cancelled
    pub status: u8,
    /// Start timestamp
    pub start_time: i64,
    /// End timestamp
    pub end_time: i64,
    /// Merkle root of this proposal's data (title, description hash)
    pub data_hash: [u8; 32],
}

/// DAO configuration stored in State Root
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone, Default)]
pub struct DaoConfig {
    /// Minimum quorum percentage (0-100)
    pub quorum_percent: u8,
    /// Approval threshold percentage (0-100)
    pub threshold_percent: u8,
    /// Default voting period in seconds
    pub voting_period_seconds: u32,
    /// Minimum tokens to create proposal
    pub min_proposal_tokens: u64,
    /// Minimum tokens to vote
    pub min_vote_tokens: u64,
    /// Fee per action in lamports (goes to DAO treasury)
    pub action_fee_lamports: u64,
    /// Enable sealed/private voting
    pub sealed_voting_enabled: bool,
    /// Enable census features
    pub census_enabled: bool,
    /// Treasury pubkey for fees
    pub treasury: Pubkey,
    /// Token mint for governance weight
    pub governance_mint: Pubkey,
}

impl StateRoot {
    /// Account size (dynamic based on max proposals)
    pub const MAX_SIZE: usize = 8 + 32 + 32 + 8 + 8 + 8 + 32 + 
        (4 + 256 * std::mem::size_of::<ProposalTally>()) + 32 + 1 + 
        std::mem::size_of::<DaoConfig>() + 64; // ~12KB
    
    /// Seeds for PDA derivation
    pub fn seeds(dao_key: &Pubkey) -> Vec<Vec<u8>> {
        vec![b"state_root".to_vec(), dao_key.to_bytes().to_vec()]
    }
    
    /// Find PDA address
    pub fn find_address(program_id: &Pubkey, dao_key: &Pubkey) -> (Pubkey, u8) {
        Pubkey::find_program_address(
            &[b"state_root", dao_key.as_ref()],
            program_id,
        )
    }
    
    /// Check if a proposal slot is active
    pub fn is_proposal_active(&self, slot_index: u8) -> bool {
        let byte_index = slot_index as usize / 8;
        let bit_index = slot_index % 8;
        if byte_index >= self.active_bitmap.len() {
            return false;
        }
        (self.active_bitmap[byte_index] & (1 << bit_index)) != 0
    }
    
    /// Set proposal slot as active/inactive
    pub fn set_proposal_active(&mut self, slot_index: u8, active: bool) {
        let byte_index = slot_index as usize / 8;
        let bit_index = slot_index % 8;
        if byte_index < self.active_bitmap.len() {
            if active {
                self.active_bitmap[byte_index] |= 1 << bit_index;
            } else {
                self.active_bitmap[byte_index] &= !(1 << bit_index);
            }
        }
    }
    
    /// Find next available proposal slot
    pub fn next_proposal_slot(&self) -> Option<u8> {
        for i in 0..=255u8 {
            if !self.is_proposal_active(i) {
                return Some(i);
            }
        }
        None
    }
}

/// Vote Prevention Bitmap - Tracks who voted on what
/// 
/// Instead of 1 PDA per voter-proposal pair, we use a compact bitmap.
/// Each voter gets a single small account that tracks all their votes.
///
/// Size: 8 + 32 + 32 + 1 + 7 = 80 bytes per voter = ~0.0006 SOL
/// This single account tracks votes across ALL proposals!
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct VoterRecord {
    /// Discriminator
    pub discriminator: [u8; 8],
    /// The voter's wallet
    pub voter: Pubkey,
    /// The DAO this record is for
    pub dao_key: Pubkey,
    /// Bitmap of proposals voted on (matches proposal_id % 256)
    pub voted_bitmap: [u8; 32],
    /// Bump seed
    pub bump: u8,
    /// Padding
    pub _padding: [u8; 7],
}

impl VoterRecord {
    pub const SIZE: usize = 80;
    
    /// Seeds for PDA derivation
    pub fn seeds<'a>(dao_key: &'a Pubkey, voter: &'a Pubkey) -> [&'a [u8]; 3] {
        [b"voter_record", dao_key.as_ref(), voter.as_ref()]
    }
    
    /// Find PDA address
    pub fn find_address(program_id: &Pubkey, dao_key: &Pubkey, voter: &Pubkey) -> (Pubkey, u8) {
        Pubkey::find_program_address(
            &Self::seeds(dao_key, voter),
            program_id,
        )
    }
    
    /// Check if voted on a proposal
    pub fn has_voted(&self, proposal_id: u64) -> bool {
        let slot = (proposal_id % 256) as u8;
        let byte_index = slot as usize / 8;
        let bit_index = slot % 8;
        (self.voted_bitmap[byte_index] & (1 << bit_index)) != 0
    }
    
    /// Mark as voted on a proposal
    pub fn mark_voted(&mut self, proposal_id: u64) {
        let slot = (proposal_id % 256) as u8;
        let byte_index = slot as usize / 8;
        let bit_index = slot % 8;
        self.voted_bitmap[byte_index] |= 1 << bit_index;
    }
}

/// Census Configuration for community polls
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CensusConfig {
    /// Census ID
    pub census_id: u64,
    /// Question/title hash
    pub question_hash: [u8; 32],
    /// Number of options
    pub option_count: u8,
    /// Response tallies per option
    pub responses: [u64; MAX_OPTIONS],
    /// Total respondents
    pub respondent_count: u32,
    /// Is anonymous
    pub is_anonymous: bool,
    /// Start time
    pub start_time: i64,
    /// End time
    pub end_time: i64,
    /// Status
    pub status: u8,
}

/// Event types for the Virtual PDA system
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EventKind {
    /// DAO initialized
    DaoInit = 0,
    /// Proposal created
    ProposalCreate = 1,
    /// Vote cast
    VoteCast = 2,
    /// Sealed vote cast (encrypted)
    SealedVoteCast = 3,
    /// Proposal finalized
    ProposalFinalize = 4,
    /// Config updated
    ConfigUpdate = 5,
    /// Census created
    CensusCreate = 6,
    /// Census response
    CensusRespond = 7,
    /// Member joined community
    MemberJoin = 8,
    /// Member left community
    MemberLeave = 9,
}

impl EventKind {
    /// Convert to u8
    pub fn to_u8(&self) -> u8 {
        match self {
            EventKind::DaoInit => 0,
            EventKind::ProposalCreate => 1,
            EventKind::VoteCast => 2,
            EventKind::SealedVoteCast => 3,
            EventKind::ProposalFinalize => 4,
            EventKind::ConfigUpdate => 5,
            EventKind::CensusCreate => 6,
            EventKind::CensusRespond => 7,
            EventKind::MemberJoin => 8,
            EventKind::MemberLeave => 9,
        }
    }
    
    /// Create from u8
    pub fn from_u8(value: u8) -> Option<Self> {
        match value {
            0 => Some(EventKind::DaoInit),
            1 => Some(EventKind::ProposalCreate),
            2 => Some(EventKind::VoteCast),
            3 => Some(EventKind::SealedVoteCast),
            4 => Some(EventKind::ProposalFinalize),
            5 => Some(EventKind::ConfigUpdate),
            6 => Some(EventKind::CensusCreate),
            7 => Some(EventKind::CensusRespond),
            8 => Some(EventKind::MemberJoin),
            9 => Some(EventKind::MemberLeave),
            _ => None,
        }
    }
}

/// Compact event header stored in memo
/// Uses manual serialization to avoid borsh version conflicts
#[derive(Debug, Clone)]
pub struct EventHeader {
    /// Event type
    pub kind: EventKind,
    /// DAO key
    pub dao_key: Pubkey,
    /// Actor (signer)
    pub actor: Pubkey,
    /// Timestamp
    pub timestamp: i64,
    /// Event-specific ID (proposal_id, census_id, etc.)
    pub ref_id: u64,
    /// Nonce for uniqueness
    pub nonce: u64,
}

impl EventHeader {
    /// Serialize to bytes (manual to avoid borsh version conflicts)
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut buf = Vec::with_capacity(97);
        buf.push(self.kind.to_u8());
        buf.extend_from_slice(self.dao_key.as_ref());
        buf.extend_from_slice(self.actor.as_ref());
        buf.extend_from_slice(&self.timestamp.to_le_bytes());
        buf.extend_from_slice(&self.ref_id.to_le_bytes());
        buf.extend_from_slice(&self.nonce.to_le_bytes());
        buf
    }
    
    /// Compute leaf hash for merkle tree
    pub fn leaf_hash(&self) -> [u8; 32] {
        use solana_program::keccak::hashv;
        hashv(&[b"chronicle_event_v2", &self.to_bytes()]).0
    }
}

/// Discriminators for account types
pub mod discriminators {
    pub const STATE_ROOT: [u8; 8] = [0x53, 0x54, 0x41, 0x54, 0x45, 0x52, 0x4F, 0x4F]; // "STATEROO"
    pub const VOTER_RECORD: [u8; 8] = [0x56, 0x4F, 0x54, 0x45, 0x52, 0x45, 0x43, 0x44]; // "VOTERRCD"
}
