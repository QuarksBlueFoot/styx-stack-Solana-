//! Chronicle Ledger Error Types

use solana_program::program_error::ProgramError;

/// Custom errors for the Chronicle Ledger program
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u32)]
pub enum ChronicleError {
    /// Invalid instruction discriminator
    InvalidInstruction = 0,
    /// Invalid merkle proof
    InvalidMerkleProof = 1,
    /// Invalid virtual PDA derivation
    InvalidVirtualPda = 2,
    /// Root hash mismatch
    RootHashMismatch = 3,
    /// Invalid event format
    InvalidEventFormat = 4,
    /// Unauthorized - signer not allowed
    Unauthorized = 5,
    /// DAO registry already initialized
    AlreadyInitialized = 6,
    /// DAO not found in registry
    DaoNotFound = 7,
    /// Event already recorded (duplicate)
    DuplicateEvent = 8,
    /// Invalid timestamp
    InvalidTimestamp = 9,
    /// Memo too large
    MemoTooLarge = 10,
    /// Invalid chunk sequence
    InvalidChunkSequence = 11,
    /// Arithmetic overflow
    Overflow = 12,
    /// Invalid account owner
    InvalidOwner = 13,
    /// Account not writable
    NotWritable = 14,
    /// Missing required signature
    MissingSignature = 15,
    /// Proposal not found
    ProposalNotFound = 16,
    /// Already voted on this proposal
    AlreadyVoted = 17,
    /// Invalid proof
    InvalidProof = 18,
    /// Voting period not started
    VotingNotStarted = 19,
    /// Voting period ended
    VotingEnded = 20,
    /// Reveal period not started
    RevealNotStarted = 21,
    /// Invalid commitment
    InvalidCommitment = 22,
}

impl From<ChronicleError> for ProgramError {
    fn from(e: ChronicleError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

impl ChronicleError {
    /// Convert error to string description
    pub fn description(&self) -> &'static str {
        match self {
            Self::InvalidInstruction => "Invalid instruction discriminator",
            Self::InvalidMerkleProof => "Invalid merkle proof",
            Self::InvalidVirtualPda => "Invalid virtual PDA derivation",
            Self::RootHashMismatch => "Root hash mismatch",
            Self::InvalidEventFormat => "Invalid event format",
            Self::Unauthorized => "Unauthorized action",
            Self::AlreadyInitialized => "DAO registry already initialized",
            Self::DaoNotFound => "DAO not found",
            Self::DuplicateEvent => "Event already recorded",
            Self::InvalidTimestamp => "Invalid timestamp",
            Self::MemoTooLarge => "Memo exceeds maximum size",
            Self::InvalidChunkSequence => "Invalid chunk sequence",
            Self::Overflow => "Arithmetic overflow",
            Self::InvalidOwner => "Invalid account owner",
            Self::NotWritable => "Account not writable",
            Self::MissingSignature => "Missing required signature",
            Self::ProposalNotFound => "Proposal not found",
            Self::AlreadyVoted => "Already voted on this proposal",
            Self::InvalidProof => "Invalid proof",
            Self::VotingNotStarted => "Voting period not started",
            Self::VotingEnded => "Voting period ended",
            Self::RevealNotStarted => "Reveal period not started",
            Self::InvalidCommitment => "Invalid commitment",
        }
    }
}
