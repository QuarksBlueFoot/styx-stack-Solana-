//! Merkle Tree utilities for Chronicle
//!
//! Implements a compact Merkle tree for verifying event inclusion without
//! storing all events on-chain.

use solana_program::hash::hashv;

/// Maximum depth of merkle tree (2^20 = 1M events per DAO)
pub const MAX_DEPTH: usize = 20;

/// Empty leaf hash (all zeros)
pub const EMPTY_LEAF: [u8; 32] = [0u8; 32];

/// Compute the hash of a leaf node
/// 
/// leaf_hash = sha256(0x00 || data)
/// The 0x00 prefix distinguishes leaves from internal nodes
pub fn hash_leaf(data: &[u8]) -> [u8; 32] {
    hashv(&[&[0x00], data]).to_bytes()
}

/// Compute the hash of an internal node
/// 
/// node_hash = sha256(0x01 || left || right)
/// The 0x01 prefix distinguishes internal nodes from leaves
pub fn hash_node(left: &[u8; 32], right: &[u8; 32]) -> [u8; 32] {
    hashv(&[&[0x01], left, right]).to_bytes()
}

/// Verify a merkle proof
/// 
/// # Arguments
/// * `leaf` - The leaf hash to verify
/// * `proof` - Array of sibling hashes from leaf to root
/// * `path` - Bitmap indicating if each sibling is on the left (0) or right (1)
/// * `root` - Expected root hash
/// 
/// # Returns
/// * `true` if the proof is valid
pub fn verify_proof(
    leaf: &[u8; 32],
    proof: &[[u8; 32]],
    path: u32,
    root: &[u8; 32],
) -> bool {
    if proof.len() > MAX_DEPTH {
        return false;
    }
    
    let mut current = *leaf;
    
    for (i, sibling) in proof.iter().enumerate() {
        let is_right = (path >> i) & 1 == 1;
        
        if is_right {
            // Current node is on the right, sibling is on the left
            current = hash_node(sibling, &current);
        } else {
            // Current node is on the left, sibling is on the right
            current = hash_node(&current, sibling);
        }
    }
    
    current == *root
}

/// Compute the merkle root from a list of leaves
/// 
/// This is used for batch verification and testing.
/// In production, the indexer computes this incrementally.
pub fn compute_root(leaves: &[[u8; 32]]) -> [u8; 32] {
    if leaves.is_empty() {
        return EMPTY_LEAF;
    }
    
    if leaves.len() == 1 {
        return leaves[0];
    }
    
    // Pad to power of 2
    let next_pow2 = leaves.len().next_power_of_two();
    let mut layer: Vec<[u8; 32]> = leaves.to_vec();
    layer.resize(next_pow2, EMPTY_LEAF);
    
    while layer.len() > 1 {
        let mut next_layer = Vec::with_capacity(layer.len() / 2);
        
        for chunk in layer.chunks(2) {
            let hash = hash_node(&chunk[0], &chunk[1]);
            next_layer.push(hash);
        }
        
        layer = next_layer;
    }
    
    layer[0]
}

/// Generate a merkle proof for a leaf at a given index
/// 
/// Returns (proof, path) where path is a bitmap of the leaf's position
pub fn generate_proof(leaves: &[[u8; 32]], index: usize) -> Option<(Vec<[u8; 32]>, u32)> {
    if index >= leaves.len() {
        return None;
    }
    
    let next_pow2 = leaves.len().next_power_of_two();
    let mut padded: Vec<[u8; 32]> = leaves.to_vec();
    padded.resize(next_pow2, EMPTY_LEAF);
    
    let depth = (next_pow2 as f64).log2() as usize;
    let mut proof = Vec::with_capacity(depth);
    let mut path: u32 = 0;
    let mut current_index = index;
    let mut layer = padded;
    
    for level in 0..depth {
        let sibling_index = if current_index % 2 == 0 {
            current_index + 1
        } else {
            current_index - 1
        };
        
        proof.push(layer[sibling_index]);
        
        // Set path bit if current is on the right
        if current_index % 2 == 1 {
            path |= 1 << level;
        }
        
        // Move to parent layer
        let mut next_layer = Vec::with_capacity(layer.len() / 2);
        for chunk in layer.chunks(2) {
            next_layer.push(hash_node(&chunk[0], &chunk[1]));
        }
        layer = next_layer;
        current_index /= 2;
    }
    
    Some((proof, path))
}

/// Compute a commitment hash for a batch of events
/// 
/// This allows verifying multiple events were included atomically
pub fn batch_commitment(event_hashes: &[[u8; 32]]) -> [u8; 32] {
    if event_hashes.is_empty() {
        return EMPTY_LEAF;
    }
    
    let mut combined = Vec::with_capacity(16 + event_hashes.len() * 32);
    combined.extend_from_slice(b"batch_commitment");
    for hash in event_hashes {
        combined.extend_from_slice(hash);
    }
    
    hashv(&[&combined]).to_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_single_leaf() {
        let leaf = hash_leaf(b"test event");
        let root = compute_root(&[leaf]);
        assert_eq!(root, leaf);
    }
    
    #[test]
    fn test_two_leaves() {
        let leaf1 = hash_leaf(b"event 1");
        let leaf2 = hash_leaf(b"event 2");
        
        let root = compute_root(&[leaf1, leaf2]);
        let expected = hash_node(&leaf1, &leaf2);
        
        assert_eq!(root, expected);
    }
    
    #[test]
    fn test_proof_verification() {
        let leaves: Vec<[u8; 32]> = (0..8)
            .map(|i| hash_leaf(format!("event {}", i).as_bytes()))
            .collect();
        
        let root = compute_root(&leaves);
        
        // Generate and verify proof for each leaf
        for (i, leaf) in leaves.iter().enumerate() {
            let (proof, path) = generate_proof(&leaves, i).unwrap();
            assert!(verify_proof(leaf, &proof, path, &root));
        }
    }
    
    #[test]
    fn test_invalid_proof() {
        let leaves: Vec<[u8; 32]> = (0..4)
            .map(|i| hash_leaf(format!("event {}", i).as_bytes()))
            .collect();
        
        let root = compute_root(&leaves);
        let (proof, path) = generate_proof(&leaves, 0).unwrap();
        
        // Wrong leaf should fail
        let wrong_leaf = hash_leaf(b"wrong");
        assert!(!verify_proof(&wrong_leaf, &proof, path, &root));
    }
}
