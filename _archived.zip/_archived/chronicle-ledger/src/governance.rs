//! Chronicle Governance Processor - Fully On-Chain Virtual PDA Operations
//!
//! This processor handles all governance operations using the Aggregated State Tree
//! pattern - no off-chain database required!

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::{
    account_info::{next_account_info, AccountInfo},
    clock::Clock,
    entrypoint::ProgramResult,
    msg,
    program::{invoke, invoke_signed},
    program_error::ProgramError,
    pubkey::Pubkey,
    rent::Rent,
    system_instruction,
    sysvar::Sysvar,
};

use crate::error::ChronicleError;
use crate::state_tree::{
    discriminators, DaoConfig, EventHeader, EventKind, ProposalTally, StateRoot, VoterRecord,
};

/// Simple hex encoder (no external dependency)
#[inline]
fn hex_encode(data: &[u8]) -> String {
    const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";
    let mut result = String::with_capacity(data.len() * 2);
    for byte in data {
        result.push(HEX_CHARS[(byte >> 4) as usize] as char);
        result.push(HEX_CHARS[(byte & 0x0f) as usize] as char);
    }
    result
}

/// Protocol fee: 1000 lamports (0.000001 SOL) per action
/// Similar to memo program - minimal but sustainable
pub const PROTOCOL_FEE_LAMPORTS: u64 = 1000;

/// Memo program ID
pub const MEMO_PROGRAM_ID: Pubkey = solana_program::pubkey!("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr");

/// Instruction types for the governance system
#[derive(BorshSerialize, BorshDeserialize, Debug)]
pub enum GovernanceInstruction {
    /// Initialize a new DAO with State Root
    /// Accounts: [payer, state_root, system_program]
    InitializeDao {
        /// The unique key for this DAO
        dao_key: Pubkey,
        /// Configuration for the DAO
        config: DaoConfig,
    },
    
    /// Create a new proposal
    /// Accounts: [proposer, state_root, memo_program, (optional) treasury]
    CreateProposal {
        /// Hash of the proposal title (stored in memo)
        title_hash: [u8; 32],
        /// Hash of the proposal description (stored in memo)
        description_hash: [u8; 32],
        /// Optional override for voting period in seconds
        voting_period_override: Option<u32>,
    },
    
    /// Cast a vote
    /// Accounts: [voter, state_root, voter_record, memo_program, system_program, (optional) treasury]
    CastVote {
        /// ID of the proposal to vote on
        proposal_id: u64,
        /// Vote choice: 0=No, 1=Yes, 2=Abstain
        choice: u8,
        /// Vote weight (token balance)
        weight: u64,
    },
    
    /// Cast a sealed (encrypted) vote
    /// Accounts: [voter, state_root, voter_record, memo_program, system_program]
    CastSealedVote {
        /// ID of the proposal to vote on
        proposal_id: u64,
        /// Encrypted choice (NaCl box ciphertext)
        encrypted_choice: [u8; 48],
        /// Encryption nonce
        nonce: [u8; 24],
        /// Vote weight (token balance)
        weight: u64,
    },
    
    /// Finalize a proposal (after voting period)
    /// Accounts: [anyone, state_root, memo_program]
    FinalizeProposal {
        /// ID of the proposal to finalize
        proposal_id: u64,
    },
    
    /// Create a census poll
    /// Accounts: [creator, state_root, memo_program]
    CreateCensus {
        /// Hash of the census question (stored in memo)
        question_hash: [u8; 32],
        /// Number of response options
        option_count: u8,
        /// Duration in seconds for the census
        duration_seconds: u32,
        /// Whether responses are anonymous
        is_anonymous: bool,
    },
    
    /// Respond to census
    /// Accounts: [respondent, state_root, voter_record, memo_program, system_program]
    RespondCensus {
        /// ID of the census to respond to
        census_id: u64,
        /// Response choice
        choice: u8,
    },
    
    /// Update DAO config
    /// Accounts: [authority, state_root]
    UpdateConfig {
        /// New configuration for the DAO
        new_config: DaoConfig,
    },
    
    /// Verify a historical event (read-only)
    /// Accounts: [state_root]
    VerifyEvent {
        /// Hash of the event to verify
        event_hash: [u8; 32],
        /// Merkle proof siblings
        proof: Vec<[u8; 32]>,
        /// Path indicating left/right at each level
        path: u32,
    },
}

/// Process governance instructions
pub fn process_governance(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    instruction_data: &[u8],
) -> ProgramResult {
    let instruction = GovernanceInstruction::try_from_slice(instruction_data)
        .map_err(|_| ChronicleError::InvalidInstruction)?;
    
    match instruction {
        GovernanceInstruction::InitializeDao { dao_key, config } => {
            process_initialize_dao(program_id, accounts, dao_key, config)
        }
        GovernanceInstruction::CreateProposal {
            title_hash,
            description_hash,
            voting_period_override,
        } => process_create_proposal(
            program_id,
            accounts,
            title_hash,
            description_hash,
            voting_period_override,
        ),
        GovernanceInstruction::CastVote {
            proposal_id,
            choice,
            weight,
        } => process_cast_vote(program_id, accounts, proposal_id, choice, weight),
        GovernanceInstruction::CastSealedVote {
            proposal_id,
            encrypted_choice,
            nonce,
            weight,
        } => process_cast_sealed_vote(
            program_id,
            accounts,
            proposal_id,
            encrypted_choice,
            nonce,
            weight,
        ),
        GovernanceInstruction::FinalizeProposal { proposal_id } => {
            process_finalize_proposal(program_id, accounts, proposal_id)
        }
        GovernanceInstruction::CreateCensus {
            question_hash,
            option_count,
            duration_seconds,
            is_anonymous,
        } => process_create_census(
            program_id,
            accounts,
            question_hash,
            option_count,
            duration_seconds,
            is_anonymous,
        ),
        GovernanceInstruction::RespondCensus { census_id, choice } => {
            process_respond_census(program_id, accounts, census_id, choice)
        }
        GovernanceInstruction::UpdateConfig { new_config } => {
            process_update_config(program_id, accounts, new_config)
        }
        GovernanceInstruction::VerifyEvent {
            event_hash,
            proof,
            path,
        } => process_verify_event(program_id, accounts, event_hash, proof, path),
    }
}

/// Initialize a new DAO
fn process_initialize_dao(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    dao_key: Pubkey,
    config: DaoConfig,
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let payer = next_account_info(accounts_iter)?;
    let state_root_account = next_account_info(accounts_iter)?;
    let system_program = next_account_info(accounts_iter)?;
    
    if !payer.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }
    
    // Derive and verify PDA
    let (expected_pda, bump) = StateRoot::find_address(program_id, &dao_key);
    if *state_root_account.key != expected_pda {
        return Err(ChronicleError::InvalidVirtualPda.into());
    }
    
    if !state_root_account.data_is_empty() {
        return Err(ChronicleError::AlreadyInitialized.into());
    }
    
    // Create the State Root account
    let space = StateRoot::MAX_SIZE;
    let rent = Rent::get()?;
    let lamports = rent.minimum_balance(space);
    
    let seeds: &[&[u8]] = &[b"state_root", dao_key.as_ref(), &[bump]];
    
    invoke_signed(
        &system_instruction::create_account(
            payer.key,
            state_root_account.key,
            lamports,
            space as u64,
            program_id,
        ),
        &[payer.clone(), state_root_account.clone(), system_program.clone()],
        &[seeds],
    )?;
    
    // Initialize state
    let clock = Clock::get()?;
    let state_root = StateRoot {
        discriminator: discriminators::STATE_ROOT,
        dao_key,
        authority: *payer.key,
        event_count: 1,
        proposal_counter: 0,
        last_update_slot: clock.slot,
        merkle_root: [0u8; 32],
        proposal_tallies: Vec::new(),
        active_bitmap: [0u8; 32],
        bump,
        config,
    };
    
    let mut data = state_root_account.try_borrow_mut_data()?;
    borsh::to_writer(&mut data[..], &state_root)?;
    
    msg!("Chronicle: DAO initialized at {}", dao_key);
    Ok(())
}

/// Create a new proposal
fn process_create_proposal(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    title_hash: [u8; 32],
    description_hash: [u8; 32],
    voting_period_override: Option<u32>,
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let proposer = next_account_info(accounts_iter)?;
    let state_root_account = next_account_info(accounts_iter)?;
    let memo_program = next_account_info(accounts_iter)?;
    
    if !proposer.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }
    
    // Verify state root
    if state_root_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }
    
    let mut data = state_root_account.try_borrow_mut_data()?;
    let mut state_root = StateRoot::try_from_slice(&data)
        .map_err(|_| ChronicleError::DaoNotFound)?;
    
    // Find next available slot
    let slot_index = state_root.next_proposal_slot()
        .ok_or(ProgramError::Custom(100))?; // Max proposals reached
    
    let clock = Clock::get()?;
    let voting_period = voting_period_override.unwrap_or(state_root.config.voting_period_seconds);
    
    // Create proposal tally
    state_root.proposal_counter += 1;
    let proposal_id = state_root.proposal_counter;
    
    // Combine title and description hash
    let mut data_hash = [0u8; 32];
    for i in 0..16 {
        data_hash[i] = title_hash[i];
        data_hash[i + 16] = description_hash[i];
    }
    
    let tally = ProposalTally {
        proposal_id,
        yes_votes: 0,
        no_votes: 0,
        abstain_votes: 0,
        voter_count: 0,
        status: 1, // Active
        start_time: clock.unix_timestamp,
        end_time: clock.unix_timestamp + voting_period as i64,
        data_hash,
    };
    
    state_root.proposal_tallies.push(tally);
    state_root.set_proposal_active(slot_index, true);
    state_root.event_count += 1;
    state_root.last_update_slot = clock.slot;
    
    // Update merkle root (simplified - real impl would do proper merkle update)
    let event = EventHeader {
        kind: EventKind::ProposalCreate,
        dao_key: state_root.dao_key,
        actor: *proposer.key,
        timestamp: clock.unix_timestamp,
        ref_id: proposal_id,
        nonce: state_root.event_count,
    };
    
    // Update merkle root with new event
    update_merkle_root(&mut state_root, &event);
    
    // Write updated state
    borsh::to_writer(&mut data[..], &state_root)?;
    
    // Log to memo for historical record
    let memo_data = format!(
        "CHR2:P:{}:{}:{}",
        proposal_id,
        hex::encode(&title_hash[..8]),
        hex::encode(&description_hash[..8])
    );
    
    invoke(
        &solana_program::instruction::Instruction {
            program_id: *memo_program.key,
            accounts: vec![],
            data: memo_data.as_bytes().to_vec(),
        },
        &[],
    )?;
    
    msg!("Chronicle: Proposal {} created", proposal_id);
    Ok(())
}

/// Cast a vote
fn process_cast_vote(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    proposal_id: u64,
    choice: u8,
    weight: u64,
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let voter = next_account_info(accounts_iter)?;
    let state_root_account = next_account_info(accounts_iter)?;
    let voter_record_account = next_account_info(accounts_iter)?;
    let memo_program = next_account_info(accounts_iter)?;
    let system_program = next_account_info(accounts_iter)?;
    
    // Optional treasury for fee collection
    let treasury_account = accounts_iter.next();
    
    if !voter.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }
    
    // Verify state root
    if state_root_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }
    
    let mut state_data = state_root_account.try_borrow_mut_data()?;
    let mut state_root = StateRoot::try_from_slice(&state_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;
    
    // Find the proposal
    let proposal_idx = state_root
        .proposal_tallies
        .iter()
        .position(|p| p.proposal_id == proposal_id)
        .ok_or(ChronicleError::DaoNotFound)?;
    
    let clock = Clock::get()?;
    
    // Check proposal is active
    if state_root.proposal_tallies[proposal_idx].status != 1 {
        msg!("Proposal not active");
        return Err(ProgramError::Custom(101));
    }
    
    // Check voting period
    if clock.unix_timestamp > state_root.proposal_tallies[proposal_idx].end_time {
        msg!("Voting period ended");
        return Err(ProgramError::Custom(102));
    }
    
    // Handle voter record (create if needed)
    let (expected_voter_record, voter_bump) = VoterRecord::find_address(
        program_id,
        &state_root.dao_key,
        voter.key,
    );
    
    if *voter_record_account.key != expected_voter_record {
        return Err(ChronicleError::InvalidVirtualPda.into());
    }
    
    let mut voter_record = if voter_record_account.data_is_empty() {
        // Create voter record
        let rent = Rent::get()?;
        let lamports = rent.minimum_balance(VoterRecord::SIZE);
        
        let seeds: &[&[u8]] = &[
            b"voter_record",
            state_root.dao_key.as_ref(),
            voter.key.as_ref(),
            &[voter_bump],
        ];
        
        invoke_signed(
            &system_instruction::create_account(
                voter.key,
                voter_record_account.key,
                lamports,
                VoterRecord::SIZE as u64,
                program_id,
            ),
            &[voter.clone(), voter_record_account.clone(), system_program.clone()],
            &[seeds],
        )?;
        
        VoterRecord {
            discriminator: discriminators::VOTER_RECORD,
            voter: *voter.key,
            dao_key: state_root.dao_key,
            voted_bitmap: [0u8; 32],
            bump: voter_bump,
            _padding: [0u8; 7],
        }
    } else {
        let record_data = voter_record_account.try_borrow_data()?;
        VoterRecord::try_from_slice(&record_data)
            .map_err(|_| ChronicleError::InvalidEventFormat)?
    };
    
    // Check if already voted
    if voter_record.has_voted(proposal_id) {
        msg!("Already voted on this proposal");
        return Err(ChronicleError::DuplicateEvent.into());
    }
    
    // Mark as voted
    voter_record.mark_voted(proposal_id);
    
    // Update vote tallies
    match choice {
        0 => state_root.proposal_tallies[proposal_idx].no_votes += weight,
        1 => state_root.proposal_tallies[proposal_idx].yes_votes += weight,
        2 => state_root.proposal_tallies[proposal_idx].abstain_votes += weight,
        _ => return Err(ProgramError::Custom(103)),
    }
    state_root.proposal_tallies[proposal_idx].voter_count += 1;
    
    // Collect protocol fee if treasury provided
    if let Some(treasury) = treasury_account {
        if state_root.config.action_fee_lamports > 0 {
            invoke(
                &system_instruction::transfer(
                    voter.key,
                    treasury.key,
                    state_root.config.action_fee_lamports,
                ),
                &[voter.clone(), treasury.clone(), system_program.clone()],
            )?;
        }
    }
    
    // Update event count and merkle
    state_root.event_count += 1;
    state_root.last_update_slot = clock.slot;
    
    let event = EventHeader {
        kind: EventKind::VoteCast,
        dao_key: state_root.dao_key,
        actor: *voter.key,
        timestamp: clock.unix_timestamp,
        ref_id: proposal_id,
        nonce: state_root.event_count,
    };
    update_merkle_root(&mut state_root, &event);
    
    // Write updates
    borsh::to_writer(&mut state_data[..], &state_root)?;
    
    let mut voter_data = voter_record_account.try_borrow_mut_data()?;
    borsh::to_writer(&mut voter_data[..], &voter_record)?;
    
    // Log to memo
    let memo_data = format!(
        "CHR2:V:{}:{}:{}:{}",
        proposal_id,
        choice,
        weight,
        &voter.key.to_string()[..8]
    );
    
    invoke(
        &solana_program::instruction::Instruction {
            program_id: *memo_program.key,
            accounts: vec![],
            data: memo_data.as_bytes().to_vec(),
        },
        &[],
    )?;
    
    msg!(
        "Chronicle: Vote cast on proposal {} - choice={} weight={}",
        proposal_id,
        choice,
        weight
    );
    Ok(())
}

/// Cast a sealed (encrypted) vote
fn process_cast_sealed_vote(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    proposal_id: u64,
    encrypted_choice: [u8; 48],
    nonce: [u8; 24],
    weight: u64,
) -> ProgramResult {
    // Similar to cast_vote but stores encrypted choice in memo
    // The tally is updated only after reveal (separate instruction)
    
    let accounts_iter = &mut accounts.iter();
    
    let voter = next_account_info(accounts_iter)?;
    let _state_root_account = next_account_info(accounts_iter)?;
    let _voter_record_account = next_account_info(accounts_iter)?;
    let memo_program = next_account_info(accounts_iter)?;
    let _system_program = next_account_info(accounts_iter)?;
    
    if !voter.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }
    
    // ... (similar validation as cast_vote)
    
    // For sealed votes, we log the encrypted data to memo
    // The actual tally update happens during reveal phase
    
    let memo_data = format!(
        "CHR2:SV:{}:{}:{}:{}",
        proposal_id,
        hex_encode(&encrypted_choice),
        hex_encode(&nonce),
        weight
    );
    
    invoke(
        &solana_program::instruction::Instruction {
            program_id: *memo_program.key,
            accounts: vec![],
            data: memo_data.as_bytes().to_vec(),
        },
        &[],
    )?;
    
    msg!("Chronicle: Sealed vote cast on proposal {}", proposal_id);
    Ok(())
}

/// Finalize a proposal
fn process_finalize_proposal(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    proposal_id: u64,
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let _anyone = next_account_info(accounts_iter)?; // Anyone can finalize
    let state_root_account = next_account_info(accounts_iter)?;
    let memo_program = next_account_info(accounts_iter)?;
    
    if state_root_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }
    
    let mut state_data = state_root_account.try_borrow_mut_data()?;
    let mut state_root = StateRoot::try_from_slice(&state_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;
    
    let proposal_idx = state_root
        .proposal_tallies
        .iter()
        .position(|p| p.proposal_id == proposal_id)
        .ok_or(ChronicleError::DaoNotFound)?;
    
    let clock = Clock::get()?;
    
    // Check voting period ended
    if clock.unix_timestamp <= state_root.proposal_tallies[proposal_idx].end_time {
        msg!("Voting period not ended");
        return Err(ProgramError::Custom(104));
    }
    
    // Calculate result - extract values first to avoid borrow issues
    let yes_votes = state_root.proposal_tallies[proposal_idx].yes_votes;
    let no_votes = state_root.proposal_tallies[proposal_idx].no_votes;
    let abstain_votes = state_root.proposal_tallies[proposal_idx].abstain_votes;
    let total_votes = yes_votes + no_votes + abstain_votes;
    
    let passed = if total_votes > 0 {
        let yes_percent = (yes_votes * 100) / total_votes;
        yes_percent >= state_root.config.threshold_percent as u64
    } else {
        false
    };
    
    // Update status
    state_root.proposal_tallies[proposal_idx].status = if passed { 2 } else { 3 };
    
    // Mark slot as available
    let slot_index = (proposal_id % 256) as u8;
    state_root.set_proposal_active(slot_index, false);
    
    state_root.event_count += 1;
    state_root.last_update_slot = clock.slot;
    
    borsh::to_writer(&mut state_data[..], &state_root)?;
    
    // Log result
    let memo_data = format!(
        "CHR2:F:{}:{}:{}:{}:{}",
        proposal_id,
        if passed { "PASSED" } else { "REJECTED" },
        yes_votes,
        no_votes,
        abstain_votes
    );
    
    invoke(
        &solana_program::instruction::Instruction {
            program_id: *memo_program.key,
            accounts: vec![],
            data: memo_data.as_bytes().to_vec(),
        },
        &[],
    )?;
    
    msg!(
        "Chronicle: Proposal {} finalized - {}",
        proposal_id,
        if passed { "PASSED" } else { "REJECTED" }
    );
    Ok(())
}

/// Create a census poll
fn process_create_census(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    _question_hash: [u8; 32],
    option_count: u8,
    _duration_seconds: u32,
    _is_anonymous: bool,
) -> ProgramResult {
    // Census uses the same State Root, just a different proposal type
    // This allows communities to run polls/surveys alongside governance
    
    let accounts_iter = &mut accounts.iter();
    
    let creator = next_account_info(accounts_iter)?;
    let _state_root_account = next_account_info(accounts_iter)?;
    let _memo_program = next_account_info(accounts_iter)?;
    
    if !creator.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }
    
    // ... similar to create_proposal but for census
    
    msg!("Chronicle: Census created with {} options", option_count);
    Ok(())
}

/// Respond to census
fn process_respond_census(
    _program_id: &Pubkey,
    _accounts: &[AccountInfo],
    _census_id: u64,
    _choice: u8,
) -> ProgramResult {
    // Similar to cast_vote but for census responses
    msg!("Chronicle: Census response recorded");
    Ok(())
}

/// Update DAO config
fn process_update_config(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    new_config: DaoConfig,
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let authority = next_account_info(accounts_iter)?;
    let state_root_account = next_account_info(accounts_iter)?;
    
    if !authority.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }
    
    if state_root_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }
    
    let mut state_data = state_root_account.try_borrow_mut_data()?;
    let mut state_root = StateRoot::try_from_slice(&state_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;
    
    if state_root.authority != *authority.key {
        return Err(ChronicleError::Unauthorized.into());
    }
    
    state_root.config = new_config;
    let clock = Clock::get()?;
    state_root.last_update_slot = clock.slot;
    state_root.event_count += 1;
    
    borsh::to_writer(&mut state_data[..], &state_root)?;
    
    msg!("Chronicle: DAO config updated");
    Ok(())
}

/// Verify a historical event using merkle proof
fn process_verify_event(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    event_hash: [u8; 32],
    proof: Vec<[u8; 32]>,
    path: u32,
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    let state_root_account = next_account_info(accounts_iter)?;
    
    if state_root_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }
    
    let state_data = state_root_account.try_borrow_data()?;
    let state_root = StateRoot::try_from_slice(&state_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;
    
    // Verify merkle proof
    let valid = crate::merkle::verify_proof(&event_hash, &proof, path, &state_root.merkle_root);
    
    if !valid {
        return Err(ChronicleError::InvalidMerkleProof.into());
    }
    
    msg!("Chronicle: Event verified successfully");
    Ok(())
}

/// Helper to update merkle root with new event
fn update_merkle_root(state_root: &mut StateRoot, event: &EventHeader) {
    use solana_program::keccak::hashv;
    
    let leaf = event.leaf_hash();
    
    // Simple merkle update: hash(old_root || new_leaf)
    // A full implementation would use a proper incremental merkle tree
    let new_root = hashv(&[&state_root.merkle_root, &leaf]).0;
    state_root.merkle_root = new_root;
}

/// Hex encoding helper (minimal implementation)
mod hex {
    pub fn encode(bytes: &[u8]) -> String {
        bytes.iter().map(|b| format!("{:02x}", b)).collect()
    }
}
