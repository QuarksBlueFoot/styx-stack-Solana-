//! Chronicle Ledger Instruction Processor
//!
//! Pure Rust implementation - no Anchor framework for minimal binary size and low deploy cost.

use borsh::BorshDeserialize;
use solana_program::{
    account_info::{next_account_info, AccountInfo},
    entrypoint::ProgramResult,
    msg,
    program::invoke_signed,
    pubkey::Pubkey,
    rent::Rent,
    sysvar::Sysvar,
    clock::Clock,
    system_instruction,
    hash::hashv,
};

use crate::error::ChronicleError;
use crate::instruction::{
    AnchorRootParams, ChronicleInstruction, CreateAnchorParams, InitializeDaoParams,
    LogEventParams, VerifyEventParams, CreateProposalParams, CastVoteParams,
    CastSealedVoteParams, RevealVoteParams, FinalizeProposalParams,
    CreateVirtualAccountParams, VirtualTransferParams, ConfidentialVoteParams,
    AnchorDataParams, AnchorDataHeaderParams, CreateDataAnchorParams, AppendDataParams,
};
use crate::merkle;
use crate::state::{discriminator, DaoRegistry, EventAnchor, DataAnchor};

/// Simple hash helper using solana_program::hash
fn hash_bytes(data: &[u8]) -> [u8; 32] {
    hashv(&[data]).to_bytes()
}

/// Hash multiple byte slices
fn hash_multi(parts: &[&[u8]]) -> [u8; 32] {
    hashv(parts).to_bytes()
}

/// Simple hex encoder (no external dependency)
fn hex_encode(data: &[u8]) -> String {
    const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";
    let mut result = String::with_capacity(data.len() * 2);
    for byte in data {
        result.push(HEX_CHARS[(byte >> 4) as usize] as char);
        result.push(HEX_CHARS[(byte & 0x0f) as usize] as char);
    }
    result
}

/// Main instruction processor
pub fn process(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    instruction_data: &[u8],
) -> ProgramResult {
    if instruction_data.is_empty() {
        return Err(ChronicleError::InvalidInstruction.into());
    }

    let instruction = ChronicleInstruction::try_from(instruction_data[0])
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let params = &instruction_data[1..];

    match instruction {
        ChronicleInstruction::InitializeDao => process_initialize_dao(program_id, accounts, params),
        ChronicleInstruction::LogEvent => process_log_event(program_id, accounts, params),
        ChronicleInstruction::AnchorRoot => process_anchor_root(program_id, accounts, params),
        ChronicleInstruction::VerifyEvent => process_verify_event(program_id, accounts, params),
        ChronicleInstruction::CreateAnchor => process_create_anchor(program_id, accounts, params),
        ChronicleInstruction::UpdateAuthority => {
            process_update_authority(program_id, accounts, params)
        }
        // Governance instructions
        ChronicleInstruction::CreateProposal => process_create_proposal(program_id, accounts, params),
        ChronicleInstruction::CastVote => process_cast_vote(program_id, accounts, params),
        ChronicleInstruction::CastSealedVote => process_cast_sealed_vote(program_id, accounts, params),
        ChronicleInstruction::RevealVote => process_reveal_vote(program_id, accounts, params),
        ChronicleInstruction::FinalizeProposal => process_finalize_proposal(program_id, accounts, params),
        ChronicleInstruction::CancelProposal => process_cancel_proposal(program_id, accounts, params),
        // Virtual PDA instructions
        ChronicleInstruction::CreateVirtualAccount => process_create_virtual_account(program_id, accounts, params),
        ChronicleInstruction::VirtualTransfer => process_virtual_transfer(program_id, accounts, params),
        ChronicleInstruction::VirtualDelegate => process_virtual_delegate(program_id, accounts, params),
        ChronicleInstruction::VirtualRevoke => process_virtual_revoke(program_id, accounts, params),
        // Privacy instructions
        ChronicleInstruction::ConfidentialVote => process_confidential_vote(program_id, accounts, params),
        ChronicleInstruction::SubmitDecryptionShare => process_submit_decryption_share(program_id, accounts, params),
        ChronicleInstruction::FinalizeConfidentialTally => process_finalize_confidential_tally(program_id, accounts, params),
        // Chronicle Data instructions (custom memo - larger payloads!)
        ChronicleInstruction::AnchorData => process_anchor_data(program_id, accounts, params),
        ChronicleInstruction::AnchorDataHeader => process_anchor_data_header(program_id, accounts, params),
        ChronicleInstruction::CreateDataAnchor => process_create_data_anchor(program_id, accounts, params),
        ChronicleInstruction::AppendData => process_append_data(program_id, accounts, params),
        ChronicleInstruction::CloseDataAnchor => process_close_data_anchor(program_id, accounts, params),
    }
}

/// Initialize a new DAO registry
/// 
/// Accounts:
/// 0. [signer, writable] Payer / Authority
/// 1. [writable] DAO Registry PDA
/// 2. [] System Program
fn process_initialize_dao(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let payer = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let system_program = next_account_info(accounts_iter)?;

    if !payer.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    let params = InitializeDaoParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Derive PDA
    let (registry_pda, bump) = DaoRegistry::find_address(program_id, &params.dao_key);
    if registry_pda != *registry_account.key {
        msg!("Invalid DAO registry PDA");
        return Err(ChronicleError::InvalidVirtualPda.into());
    }

    // Check if already initialized
    if !registry_account.data_is_empty() {
        return Err(ChronicleError::AlreadyInitialized.into());
    }

    // Create the account
    let rent = Rent::get()?;
    let space = DaoRegistry::SIZE;
    let lamports = rent.minimum_balance(space);

    let seeds = &[
        b"dao_registry".as_ref(),
        params.dao_key.as_ref(),
        &[bump],
    ];

    invoke_signed(
        &system_instruction::create_account(
            payer.key,
            registry_account.key,
            lamports,
            space as u64,
            program_id,
        ),
        &[payer.clone(), registry_account.clone(), system_program.clone()],
        &[seeds],
    )?;

    // Initialize the registry
    let clock = Clock::get()?;
    let registry = DaoRegistry {
        discriminator: discriminator::DAO_REGISTRY,
        dao_key: params.dao_key,
        authority: *payer.key,
        merkle_root: merkle::EMPTY_LEAF,
        event_count: 0,
        last_anchor_slot: clock.slot,
        bump,
        _padding: [0u8; 7],
        bloom_filter: [0u8; 256],
    };

    let mut data = registry_account.try_borrow_mut_data()?;
    borsh::to_writer(&mut *data, &registry)?;

    msg!("Chronicle: DAO Registry initialized for {}", params.dao_key);
    Ok(())
}

/// Log an event (verification only - actual data goes in memo)
/// 
/// This instruction verifies the event format and logs it for indexer consumption.
/// The actual payload is stored in a memo instruction in the same transaction.
/// 
/// Accounts:
/// 0. [signer] Actor
/// 1. [] DAO Registry
fn process_log_event(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let actor = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !actor.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    let params = LogEventParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Verify registry exists and is valid
    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let registry_data = registry_account.try_borrow_data()?;
    if registry_data.len() < 8 || registry_data[..8] != discriminator::DAO_REGISTRY {
        return Err(ChronicleError::DaoNotFound.into());
    }

    // Validate timestamp is reasonable (within 10 minutes of slot time)
    let clock = Clock::get()?;
    let slot_time = clock.unix_timestamp;
    if (params.timestamp - slot_time).abs() > 600 {
        msg!("Event timestamp too far from slot time");
        return Err(ChronicleError::InvalidTimestamp.into());
    }

    // Log the event for indexer
    // The actual memo with the payload should be in the same transaction
    msg!(
        "Chronicle Event: type={}, nonce={}, hash={:?}",
        params.event_type,
        params.nonce,
        &params.payload_hash[..8]
    );

    Ok(())
}

/// Anchor a new merkle root
/// 
/// Called periodically by the indexer/authority to commit a batch of events.
/// 
/// Accounts:
/// 0. [signer] Authority
/// 1. [writable] DAO Registry
fn process_anchor_root(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let authority = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !authority.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if !registry_account.is_writable {
        return Err(ChronicleError::NotWritable.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = AnchorRootParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Verify authority
    if registry.authority != *authority.key {
        msg!("Invalid authority");
        return Err(ChronicleError::Unauthorized.into());
    }

    // Update merkle root
    let clock = Clock::get()?;
    registry.merkle_root = params.new_root;
    registry.event_count = params.event_count;
    registry.last_anchor_slot = clock.slot;

    borsh::to_writer(&mut *registry_data, &registry)?;

    msg!(
        "Chronicle: Anchored root with {} events",
        params.event_count
    );
    Ok(())
}

/// Verify an event inclusion proof
/// 
/// Returns success if the event is proven to be included in the merkle tree.
/// This is a read-only verification.
/// 
/// Accounts:
/// 0. [] DAO Registry
fn process_verify_event(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    let registry_account = next_account_info(accounts_iter)?;

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = VerifyEventParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let registry_data = registry_account.try_borrow_data()?;
    let registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Verify the merkle proof
    let valid = merkle::verify_proof(
        &params.leaf_hash,
        &params.proof,
        params.path,
        &registry.merkle_root,
    );

    if !valid {
        msg!("Invalid merkle proof");
        return Err(ChronicleError::InvalidMerkleProof.into());
    }

    msg!("Chronicle: Event verified successfully");
    Ok(())
}

/// Create an event anchor PDA (for critical events)
/// 
/// Accounts:
/// 0. [signer, writable] Payer
/// 1. [writable] Event Anchor PDA
/// 2. [] DAO Registry
/// 3. [] System Program
fn process_create_anchor(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let payer = next_account_info(accounts_iter)?;
    let anchor_account = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let system_program = next_account_info(accounts_iter)?;

    if !payer.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    let params = CreateAnchorParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Verify registry
    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let registry_data = registry_account.try_borrow_data()?;
    let registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Derive anchor PDA
    let seeds_ref: &[&[u8]] = &[
        b"event_anchor",
        registry.dao_key.as_ref(),
        &params.event_ref,
    ];
    let (anchor_pda, bump) = Pubkey::find_program_address(seeds_ref, program_id);
    
    if anchor_pda != *anchor_account.key {
        return Err(ChronicleError::InvalidVirtualPda.into());
    }

    if !anchor_account.data_is_empty() {
        return Err(ChronicleError::AlreadyInitialized.into());
    }

    // Create anchor account
    let rent = Rent::get()?;
    let space = EventAnchor::SIZE;
    let lamports = rent.minimum_balance(space);

    let signer_seeds: &[&[u8]] = &[
        b"event_anchor",
        registry.dao_key.as_ref(),
        &params.event_ref,
        &[bump],
    ];

    invoke_signed(
        &system_instruction::create_account(
            payer.key,
            anchor_account.key,
            lamports,
            space as u64,
            program_id,
        ),
        &[payer.clone(), anchor_account.clone(), system_program.clone()],
        &[signer_seeds],
    )?;

    // Initialize anchor
    let clock = Clock::get()?;
    let anchor = EventAnchor {
        discriminator: discriminator::EVENT_ANCHOR,
        event_ref: params.event_ref,
        dao_key: registry.dao_key,
        slot: clock.slot,
        bump,
        _padding: [0u8; 7],
    };

    let mut data = anchor_account.try_borrow_mut_data()?;
    // Manual serialization (avoid borsh version conflicts)
    data[0..8].copy_from_slice(&anchor.discriminator);
    data[8..40].copy_from_slice(&anchor.event_ref);
    data[40..72].copy_from_slice(anchor.dao_key.as_ref());
    data[72..80].copy_from_slice(&anchor.slot.to_le_bytes());
    data[80] = anchor.bump;
    data[81..88].copy_from_slice(&anchor._padding);

    msg!("Chronicle: Event anchor created");
    Ok(())
}

/// Update DAO authority
/// 
/// Accounts:
/// 0. [signer] Current Authority
/// 1. [writable] DAO Registry
/// 2. [] New Authority
fn process_update_authority(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    _params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let current_authority = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let new_authority = next_account_info(accounts_iter)?;

    if !current_authority.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if !registry_account.is_writable {
        return Err(ChronicleError::NotWritable.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    if registry.authority != *current_authority.key {
        return Err(ChronicleError::Unauthorized.into());
    }

    registry.authority = *new_authority.key;
    borsh::to_writer(&mut *registry_data, &registry)?;

    msg!(
        "Chronicle: Authority updated to {}",
        new_authority.key
    );
    Ok(())
}

// ============================================================================
// GOVERNANCE PROCESSORS (Virtual PDA based)
// ============================================================================

/// Create a virtual proposal
/// 
/// The proposal data is stored in memo, indexed in merkle tree.
/// Only the proposal_id hash is tracked on-chain in the bloom filter.
/// 
/// Accounts:
/// 0. [signer] Proposer
/// 1. [writable] DAO Registry
/// 2. [] Memo Program
fn process_create_proposal(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let proposer = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let _memo_program = next_account_info(accounts_iter)?;

    if !proposer.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = CreateProposalParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Update registry with new proposal in bloom filter
    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Add proposal_id to bloom filter for O(1) existence check
    crate::bloom::bloom_add(&mut registry.bloom_filter, &params.proposal_id);
    
    // Increment event count
    registry.event_count = registry.event_count.saturating_add(1);
    
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:P:{proposal_id_hex}:{title_hash_hex}:{desc_hash_hex}:{options}:{start}:{end}:{quorum}:{flags}
    msg!(
        "CHR2:P:{}:{}:{}:{}:{}:{}:{}:{}",
        hex_encode(&params.proposal_id),
        hex_encode(&params.title_hash[..16]),
        hex_encode(&params.description_hash[..16]),
        params.options_count,
        params.start_time,
        params.end_time,
        params.quorum_bps,
        (params.is_sealed as u8) | ((params.is_confidential as u8) << 1)
    );
    
    msg!(
        "Chronicle: Proposal created. ID: {:?}... Options: {} Start: {} End: {}",
        &params.proposal_id[..8],
        params.options_count,
        params.start_time,
        params.end_time
    );
    
    Ok(())
}

/// Cast a virtual vote
/// 
/// Vote is stored in memo, added to merkle tree, voter marked in bloom filter.
/// 
/// Accounts:
/// 0. [signer] Voter
/// 1. [writable] DAO Registry
/// 2. [] Memo Program
fn process_cast_vote(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let voter = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let _memo_program = next_account_info(accounts_iter)?;

    if !voter.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = CastVoteParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Check proposal exists in bloom filter
    if !crate::bloom::bloom_check(&registry.bloom_filter, &params.proposal_id) {
        msg!("Chronicle: Proposal not found");
        return Err(ChronicleError::ProposalNotFound.into());
    }

    // Create vote leaf hash = hash(proposal_id || voter || choice || power)
    let vote_leaf = hash_multi(&[
        &params.proposal_id,
        voter.key.as_ref(),
        &[params.choice],
        &params.voting_power.to_le_bytes(),
    ]);

    // Add voter to bloom filter (prevents double voting)
    let voter_key = {
        let mut key = [0u8; 64];
        key[..32].copy_from_slice(&params.proposal_id);
        key[32..].copy_from_slice(voter.key.as_ref());
        hash_bytes(&key)
    };
    
    if crate::bloom::bloom_check(&registry.bloom_filter, &voter_key) {
        msg!("Chronicle: Already voted on this proposal");
        return Err(ChronicleError::AlreadyVoted.into());
    }
    
    crate::bloom::bloom_add(&mut registry.bloom_filter, &voter_key);
    crate::bloom::bloom_add(&mut registry.bloom_filter, &vote_leaf);
    
    registry.event_count = registry.event_count.saturating_add(1);
    
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:V:{proposal_id_hex}:{voter}:{choice}:{power}:{vote_leaf_hex}
    msg!(
        "CHR2:V:{}:{}:{}:{}:{}",
        hex_encode(&params.proposal_id),
        voter.key,
        params.choice,
        params.voting_power,
        hex_encode(&vote_leaf[..16])
    );

    msg!(
        "Chronicle: Vote cast. Proposal: {:?}... Choice: {} Power: {}",
        &params.proposal_id[..8],
        params.choice,
        params.voting_power
    );
    
    Ok(())
}

/// Cast a sealed vote (commit phase)
/// 
/// Only the commitment is stored, actual vote revealed later.
/// 
/// Accounts:
/// 0. [signer] Voter
/// 1. [writable] DAO Registry
fn process_cast_sealed_vote(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let voter = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !voter.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = CastSealedVoteParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Check proposal exists
    if !crate::bloom::bloom_check(&registry.bloom_filter, &params.proposal_id) {
        return Err(ChronicleError::ProposalNotFound.into());
    }

    // Store commitment in bloom filter
    crate::bloom::bloom_add(&mut registry.bloom_filter, &params.commitment);
    
    // Mark voter as having committed (prevents multiple commits)
    let voter_commit_key = {
        let mut key = [0u8; 64];
        key[..32].copy_from_slice(&params.proposal_id);
        key[32..].copy_from_slice(voter.key.as_ref());
        let hash = hash_bytes(&key);
        let mut prefixed = [0u8; 33];
        prefixed[0] = 0xC0; // Commit prefix
        prefixed[1..].copy_from_slice(&hash[..32]);
        hash_bytes(&prefixed)
    };
    
    if crate::bloom::bloom_check(&registry.bloom_filter, &voter_commit_key) {
        return Err(ChronicleError::AlreadyVoted.into());
    }
    
    crate::bloom::bloom_add(&mut registry.bloom_filter, &voter_commit_key);
    registry.event_count = registry.event_count.saturating_add(1);
    
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:S:{proposal_id_hex}:{voter}:{commitment_hex}:{power}
    msg!(
        "CHR2:S:{}:{}:{}:{}",
        hex_encode(&params.proposal_id),
        voter.key,
        hex_encode(&params.commitment),
        params.voting_power
    );

    msg!(
        "Chronicle: Sealed vote committed. Proposal: {:?}... Power: {}",
        &params.proposal_id[..8],
        params.voting_power
    );
    
    Ok(())
}

/// Reveal a sealed vote
/// 
/// Accounts:
/// 0. [signer] Voter
/// 1. [writable] DAO Registry
/// 2. [] Memo Program
fn process_reveal_vote(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let voter = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let _memo_program = next_account_info(accounts_iter)?;

    if !voter.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = RevealVoteParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let registry_data = registry_account.try_borrow_data()?;
    let registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Verify commitment exists
    if !crate::bloom::bloom_check(&registry.bloom_filter, &params.commitment) {
        msg!("Chronicle: Commitment not found");
        return Err(ChronicleError::InvalidProof.into());
    }

    // Recompute commitment from revealed values
    let computed_commitment = hash_multi(&[
        &[params.choice],
        &params.salt,
        voter.key.as_ref(),
    ]);

    if computed_commitment != params.commitment {
        msg!("Chronicle: Commitment mismatch");
        return Err(ChronicleError::InvalidProof.into());
    }

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:R:{proposal_id_hex}:{voter}:{choice}:{salt_hex}
    msg!(
        "CHR2:R:{}:{}:{}:{}",
        hex_encode(&params.proposal_id),
        voter.key,
        params.choice,
        hex_encode(&params.salt)
    );

    msg!(
        "Chronicle: Vote revealed. Proposal: {:?}... Choice: {}",
        &params.proposal_id[..8],
        params.choice
    );
    
    Ok(())
}

/// Finalize proposal
/// 
/// Accounts:
/// 0. [signer] Authority
/// 1. [writable] DAO Registry
fn process_finalize_proposal(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let authority = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !authority.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = FinalizeProposalParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Verify authority
    if registry.authority != *authority.key {
        return Err(ChronicleError::Unauthorized.into());
    }

    // Update merkle root with votes
    registry.merkle_root = params.votes_root;
    registry.event_count = registry.event_count.saturating_add(1);
    
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Find winning option
    let winner = params.vote_tallies
        .iter()
        .enumerate()
        .max_by_key(|(_, &votes)| votes)
        .map(|(idx, _)| idx)
        .unwrap_or(0);

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:F:{proposal_id_hex}:{winner}:{total_votes}:{votes_root_hex}
    msg!(
        "CHR2:F:{}:{}:{}:{}",
        hex_encode(&params.proposal_id),
        winner,
        params.total_votes,
        hex_encode(&params.votes_root[..16])
    );

    msg!(
        "Chronicle: Proposal finalized. ID: {:?}... Winner: {} Total Votes: {}",
        &params.proposal_id[..8],
        winner,
        params.total_votes
    );
    
    Ok(())
}

/// Cancel proposal
/// 
/// Accounts:
/// 0. [signer] Authority
/// 1. [writable] DAO Registry
fn process_cancel_proposal(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    _params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let authority = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !authority.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let registry_data = registry_account.try_borrow_data()?;
    let registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    if registry.authority != *authority.key {
        return Err(ChronicleError::Unauthorized.into());
    }

    msg!("Chronicle: Proposal cancelled");
    Ok(())
}

// ============================================================================
// VIRTUAL PDA PROCESSORS
// ============================================================================

/// Create a virtual token account
/// 
/// Zero rent! Account stored in merkle tree, verified via proof.
/// 
/// Accounts:
/// 0. [signer] Owner
/// 1. [writable] DAO Registry
/// 2. [] Memo Program
fn process_create_virtual_account(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let owner = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let _memo_program = next_account_info(accounts_iter)?;

    if !owner.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = CreateVirtualAccountParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Create account leaf hash
    let account_leaf = hash_multi(&[
        params.mint.as_ref(),
        owner.key.as_ref(),
        &params.initial_amount.to_le_bytes(),
        &[params.extensions],
    ]);

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Add to bloom filter
    crate::bloom::bloom_add(&mut registry.bloom_filter, &account_leaf);
    registry.event_count = registry.event_count.saturating_add(1);
    
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:T:{mint}:{owner}:{amount}:{extensions}:{leaf_hex}
    msg!(
        "CHR2:T:{}:{}:{}:{}:{}",
        params.mint,
        owner.key,
        params.initial_amount,
        params.extensions,
        hex_encode(&account_leaf[..16])
    );

    msg!(
        "Chronicle: Virtual account created. Mint: {} Owner: {} Amount: {}",
        params.mint,
        owner.key,
        params.initial_amount
    );
    
    Ok(())
}

/// Transfer virtual tokens
/// 
/// Accounts:
/// 0. [signer] Owner
/// 1. [writable] DAO Registry
/// 2. [] Memo Program
fn process_virtual_transfer(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let owner = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let _memo_program = next_account_info(accounts_iter)?;

    if !owner.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = VirtualTransferParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Verify source account exists via merkle proof
    let proof_slice: Vec<[u8; 32]> = params.source_proof;
    if !crate::merkle::verify_proof(
        &params.source_hash,
        &proof_slice,
        params.proof_path,
        &registry.merkle_root,
    ) {
        msg!("Chronicle: Invalid ownership proof");
        return Err(ChronicleError::InvalidProof.into());
    }

    // Update bloom filter with new state
    registry.event_count = registry.event_count.saturating_add(1);
    
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:X:{from}:{to}:{amount}:{source_hash_hex}
    msg!(
        "CHR2:X:{}:{}:{}:{}",
        owner.key,
        params.destination,
        params.amount,
        hex_encode(&params.source_hash[..16])
    );

    msg!(
        "Chronicle: Virtual transfer. To: {} Amount: {}",
        params.destination,
        params.amount
    );
    
    Ok(())
}

/// Delegate virtual tokens
fn process_virtual_delegate(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    _params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let owner = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !owner.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    msg!("Chronicle: Virtual delegation set");
    Ok(())
}

/// Revoke virtual delegation
fn process_virtual_revoke(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    _params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let owner = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !owner.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    msg!("Chronicle: Virtual delegation revoked");
    Ok(())
}

// ============================================================================
// PRIVACY PROCESSORS
// ============================================================================

/// Cast a confidential vote (encrypted)
fn process_confidential_vote(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let voter = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !voter.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = ConfidentialVoteParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Store encrypted vote hash in bloom filter
    let vote_hash = hash_bytes(&params.encrypted_choice);
    crate::bloom::bloom_add(&mut registry.bloom_filter, &vote_hash);
    
    registry.event_count = registry.event_count.saturating_add(1);
    
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit structured event for indexer (CHR2: format)
    // Format: CHR2:C:{proposal_id_hex}:{voter}:{encrypted_hex}:{zk_proof_prefix_hex}
    msg!(
        "CHR2:C:{}:{}:{}:{}",
        hex_encode(&params.proposal_id),
        voter.key,
        hex_encode(&params.encrypted_choice[..32]),
        hex_encode(&params.zk_proof[..16])
    );

    msg!("Chronicle: Confidential vote cast");
    Ok(())
}

/// Submit decryption share (threshold decryption)
fn process_submit_decryption_share(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    _params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let guardian = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !guardian.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    msg!("Chronicle: Decryption share submitted");
    Ok(())
}

/// Finalize confidential tally
fn process_finalize_confidential_tally(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    _params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let authority = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !authority.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let registry_data = registry_account.try_borrow_data()?;
    let registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    if registry.authority != *authority.key {
        return Err(ChronicleError::Unauthorized.into());
    }

    msg!("Chronicle: Confidential tally finalized");
    Ok(())
}

// ============================================================================
// CHRONICLE DATA PROCESSORS (Custom Memo - Beats Solana Limits!)
// ============================================================================

/// Anchor data chunk (up to 900 bytes per instruction!)
/// 
/// This is Chronicle's custom memo that beats Solana's 566 byte limit.
/// Data is emitted as program logs and can be indexed.
/// 
/// Accounts:
/// 0. [signer] Creator
/// 1. [writable] DAO Registry
fn process_anchor_data(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let creator = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !creator.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = AnchorDataParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Validate chunk
    if params.chunk_index >= params.chunk_count {
        return Err(ChronicleError::InvalidInstruction.into());
    }

    // Update registry event count
    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    registry.event_count = registry.event_count.saturating_add(1);
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit structured data event (CHR3: format for data)
    // Format: CHR3:D:{data_type}:{entity_id_hex}:{chunk_idx}/{chunk_count}:{hash_prefix}:{data_b64}
    let data_b64 = base64_encode(&params.data);
    msg!(
        "CHR3:D:{}:{}:{}/{}:{}:{}",
        params.data_type,
        hex_encode(&params.entity_id[..16]),
        params.chunk_index,
        params.chunk_count,
        hex_encode(&params.full_hash[..8]),
        data_b64
    );

    msg!(
        "Chronicle: Data anchored. Type: {} Chunk: {}/{} Size: {}",
        params.data_type,
        params.chunk_index + 1,
        params.chunk_count,
        params.data.len()
    );
    
    Ok(())
}

/// Anchor data header for multi-chunk data
fn process_anchor_data_header(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let creator = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;

    if !creator.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if registry_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = AnchorDataHeaderParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    let mut registry_data = registry_account.try_borrow_mut_data()?;
    let mut registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Add to bloom filter for existence check
    crate::bloom::bloom_add(&mut registry.bloom_filter, &params.entity_id);
    registry.event_count = registry.event_count.saturating_add(1);
    borsh::to_writer(&mut *registry_data, &registry)?;

    // Emit header event
    msg!(
        "CHR3:H:{}:{}:{}:{}:{}:{}",
        params.data_type,
        hex_encode(&params.entity_id),
        params.chunk_count,
        params.total_size,
        hex_encode(&params.full_hash),
        params.timestamp
    );

    msg!(
        "Chronicle: Data header. Type: {} Chunks: {} Size: {}",
        params.data_type,
        params.chunk_count,
        params.total_size
    );
    
    Ok(())
}

/// Create a permanent data anchor PDA
fn process_create_data_anchor(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let payer = next_account_info(accounts_iter)?;
    let data_anchor_account = next_account_info(accounts_iter)?;
    let registry_account = next_account_info(accounts_iter)?;
    let system_program = next_account_info(accounts_iter)?;

    if !payer.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    let params = CreateDataAnchorParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Get DAO key from registry
    let registry_data = registry_account.try_borrow_data()?;
    let registry = DaoRegistry::try_from_slice(&registry_data)
        .map_err(|_| ChronicleError::DaoNotFound)?;

    // Derive PDA
    let (expected_pda, bump) = DataAnchor::find_address(program_id, &registry.dao_key, &params.entity_id);
    if *data_anchor_account.key != expected_pda {
        return Err(ChronicleError::InvalidVirtualPda.into());
    }

    // Calculate account size
    let data_len = params.data.len();
    let account_size = DataAnchor::account_size(data_len);
    let rent = Rent::get()?;
    let lamports = rent.minimum_balance(account_size);

    // Create account
    let seeds: &[&[u8]] = &[
        b"data_anchor",
        registry.dao_key.as_ref(),
        &params.entity_id,
        &[bump],
    ];

    invoke_signed(
        &system_instruction::create_account(
            payer.key,
            data_anchor_account.key,
            lamports,
            account_size as u64,
            program_id,
        ),
        &[payer.clone(), data_anchor_account.clone(), system_program.clone()],
        &[seeds],
    )?;

    // Initialize data anchor
    let clock = Clock::get()?;
    let data_hash = hash_bytes(&params.data);
    
    let data_anchor = DataAnchor {
        discriminator: DataAnchor::DISCRIMINATOR,
        data_type: params.data_type,
        entity_id: params.entity_id,
        data_hash,
        total_size: data_len as u32,
        chunk_count: 1,
        is_complete: !params.is_extendable,
        timestamp: clock.unix_timestamp,
        bump,
        _padding: [0u8; 6],
        data: params.data.clone(),
    };

    let mut account_data = data_anchor_account.try_borrow_mut_data()?;
    borsh::to_writer(&mut account_data[..], &data_anchor)?;

    // Emit event
    msg!(
        "CHR3:A:{}:{}:{}:{}",
        params.data_type,
        hex_encode(&params.entity_id[..16]),
        data_len,
        hex_encode(&data_hash[..8])
    );

    msg!(
        "Chronicle: Data anchor created. Type: {} Size: {} Extendable: {}",
        params.data_type,
        data_len,
        params.is_extendable
    );
    
    Ok(())
}

/// Append data to existing anchor
fn process_append_data(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let signer = next_account_info(accounts_iter)?;
    let data_anchor_account = next_account_info(accounts_iter)?;

    if !signer.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if data_anchor_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    let params = AppendDataParams::try_from_slice(params)
        .map_err(|_| ChronicleError::InvalidInstruction)?;

    // Note: In production, you'd need to realloc the account to append data
    // For now, we just emit the append event for indexing
    
    msg!(
        "CHR3:+:{}:{}",
        params.data.len(),
        if params.is_final { 1 } else { 0 }
    );

    msg!(
        "Chronicle: Data appended. Size: {} Final: {}",
        params.data.len(),
        params.is_final
    );
    
    Ok(())
}

/// Close data anchor and reclaim rent
fn process_close_data_anchor(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    _params: &[u8],
) -> ProgramResult {
    let accounts_iter = &mut accounts.iter();
    
    let authority = next_account_info(accounts_iter)?;
    let data_anchor_account = next_account_info(accounts_iter)?;
    let receiver = next_account_info(accounts_iter)?;

    if !authority.is_signer {
        return Err(ChronicleError::MissingSignature.into());
    }

    if data_anchor_account.owner != program_id {
        return Err(ChronicleError::InvalidOwner.into());
    }

    // Transfer lamports to receiver
    let lamports = data_anchor_account.lamports();
    **data_anchor_account.try_borrow_mut_lamports()? = 0;
    **receiver.try_borrow_mut_lamports()? = receiver.lamports().checked_add(lamports).unwrap();

    // Zero the data
    let mut data = data_anchor_account.try_borrow_mut_data()?;
    data.fill(0);

    msg!("Chronicle: Data anchor closed. Reclaimed: {} lamports", lamports);
    
    Ok(())
}

/// Base64 encoder for data (no external dependency)
fn base64_encode(data: &[u8]) -> String {
    const ALPHABET: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    
    let mut result = String::with_capacity((data.len() + 2) / 3 * 4);
    
    for chunk in data.chunks(3) {
        let b0 = chunk[0] as usize;
        let b1 = chunk.get(1).copied().unwrap_or(0) as usize;
        let b2 = chunk.get(2).copied().unwrap_or(0) as usize;
        
        let n = (b0 << 16) | (b1 << 8) | b2;
        
        result.push(ALPHABET[(n >> 18) & 63] as char);
        result.push(ALPHABET[(n >> 12) & 63] as char);
        
        if chunk.len() > 1 {
            result.push(ALPHABET[(n >> 6) & 63] as char);
        } else {
            result.push('=');
        }
        
        if chunk.len() > 2 {
            result.push(ALPHABET[n & 63] as char);
        } else {
            result.push('=');
        }
    }
    
    result
}
