//! Chronicle Ledger Instructions
//!
//! All instructions use a simple discriminator-based encoding for minimal overhead.

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::pubkey::Pubkey;

/// Instruction discriminators (single byte for efficiency)
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum ChronicleInstruction {
    // ========== Core Instructions (0-15) ==========
    /// Initialize a new DAO registry
    /// Accounts: [signer, dao_registry (writable), system_program]
    InitializeDao = 0,
    
    /// Log an event via memo (no PDA creation, just verification)
    /// Accounts: [signer, dao_registry, memo_program]
    LogEvent = 1,
    
    /// Anchor a new merkle root (batch finalization)
    /// Accounts: [authority (signer), dao_registry (writable)]
    AnchorRoot = 2,
    
    /// Verify an event inclusion proof
    /// Accounts: [dao_registry]
    VerifyEvent = 3,
    
    /// Create an event anchor PDA (optional, for critical events)
    /// Accounts: [signer, event_anchor (writable), dao_registry, system_program]
    CreateAnchor = 4,
    
    /// Update DAO authority
    /// Accounts: [current_authority (signer), dao_registry (writable), new_authority]
    UpdateAuthority = 5,

    // ========== Governance Instructions (16-31) ==========
    /// Create a virtual proposal (stored in memo, indexed in merkle tree)
    /// Accounts: [proposer (signer), dao_registry (writable), memo_program]
    CreateProposal = 16,
    
    /// Cast a virtual vote (stored in merkle tree, bloom filter updated)
    /// Accounts: [voter (signer), dao_registry (writable), memo_program]
    CastVote = 17,
    
    /// Cast a sealed (commit-reveal) vote
    /// Accounts: [voter (signer), dao_registry (writable)]
    CastSealedVote = 18,
    
    /// Reveal a sealed vote
    /// Accounts: [voter (signer), dao_registry (writable), memo_program]
    RevealVote = 19,
    
    /// Finalize proposal (tally votes, update state)
    /// Accounts: [authority (signer), dao_registry (writable)]
    FinalizeProposal = 20,
    
    /// Cancel proposal (authority only)
    /// Accounts: [authority (signer), dao_registry (writable)]
    CancelProposal = 21,

    // ========== Virtual PDA Instructions (32-47) ==========
    /// Create a virtual token account (zero rent SPL-compatible)
    /// Accounts: [owner (signer), dao_registry (writable), memo_program]
    CreateVirtualAccount = 32,
    
    /// Transfer virtual tokens
    /// Accounts: [owner (signer), dao_registry (writable), memo_program]
    VirtualTransfer = 33,
    
    /// Delegate virtual tokens
    /// Accounts: [owner (signer), dao_registry (writable)]
    VirtualDelegate = 34,
    
    /// Revoke virtual delegation
    /// Accounts: [owner (signer), dao_registry (writable)]
    VirtualRevoke = 35,

    // ========== Privacy Instructions (48-63) ==========
    /// Submit encrypted vote (confidential voting)
    /// Accounts: [voter (signer), dao_registry (writable)]
    ConfidentialVote = 48,
    
    /// Submit threshold decryption share
    /// Accounts: [guardian (signer), dao_registry (writable)]
    SubmitDecryptionShare = 49,
    
    /// Finalize confidential tally
    /// Accounts: [authority (signer), dao_registry (writable)]
    FinalizeConfidentialTally = 50,

    // ========== Chronicle Data Instructions (64-79) ==========
    // Custom memo/data anchoring - beats Solana memo limits!
    
    /// Anchor a data chunk (up to 900 bytes per instruction)
    /// Multiple chunks can be sent in one tx for large data.
    /// Accounts: [signer, dao_registry (writable)]
    AnchorData = 64,
    
    /// Anchor multi-chunk data header (for data > 900 bytes)
    /// Accounts: [signer, dao_registry (writable)]
    AnchorDataHeader = 65,
    
    /// Create a permanent data anchor PDA (for critical data)
    /// Accounts: [signer, data_anchor (writable), dao_registry, system_program]
    CreateDataAnchor = 66,
    
    /// Append data to existing anchor (for very large data)
    /// Accounts: [signer, data_anchor (writable)]
    AppendData = 67,
    
    /// Close data anchor and reclaim rent
    /// Accounts: [authority (signer), data_anchor (writable), receiver]
    CloseDataAnchor = 68,
}

impl TryFrom<u8> for ChronicleInstruction {
    type Error = ();
    
    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            0 => Ok(Self::InitializeDao),
            1 => Ok(Self::LogEvent),
            2 => Ok(Self::AnchorRoot),
            3 => Ok(Self::VerifyEvent),
            4 => Ok(Self::CreateAnchor),
            5 => Ok(Self::UpdateAuthority),
            // Governance
            16 => Ok(Self::CreateProposal),
            17 => Ok(Self::CastVote),
            18 => Ok(Self::CastSealedVote),
            19 => Ok(Self::RevealVote),
            20 => Ok(Self::FinalizeProposal),
            21 => Ok(Self::CancelProposal),
            // Virtual PDAs
            32 => Ok(Self::CreateVirtualAccount),
            33 => Ok(Self::VirtualTransfer),
            34 => Ok(Self::VirtualDelegate),
            35 => Ok(Self::VirtualRevoke),
            // Privacy
            48 => Ok(Self::ConfidentialVote),
            49 => Ok(Self::SubmitDecryptionShare),
            50 => Ok(Self::FinalizeConfidentialTally),
            // Chronicle Data
            64 => Ok(Self::AnchorData),
            65 => Ok(Self::AnchorDataHeader),
            66 => Ok(Self::CreateDataAnchor),
            67 => Ok(Self::AppendData),
            68 => Ok(Self::CloseDataAnchor),
            _ => Err(()),
        }
    }
}

/// Initialize DAO parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct InitializeDaoParams {
    /// The DAO's unique key (council mint, treasury, etc.)
    pub dao_key: Pubkey,
}

/// Log event parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct LogEventParams {
    /// Event type
    pub event_type: u8,
    /// Event nonce (for uniqueness)
    pub nonce: u64,
    /// Hash of the full payload (payload itself goes in memo)
    pub payload_hash: [u8; 32],
    /// Unix timestamp
    pub timestamp: i64,
}

/// Anchor root parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct AnchorRootParams {
    /// New merkle root
    pub new_root: [u8; 32],
    /// Number of events included in this root
    pub event_count: u64,
}

/// Verify event parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct VerifyEventParams {
    /// The leaf hash to verify
    pub leaf_hash: [u8; 32],
    /// Merkle proof (sibling hashes)
    pub proof: Vec<[u8; 32]>,
    /// Path bitmap
    pub path: u32,
}

/// Create anchor parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CreateAnchorParams {
    /// Event reference (hash or virtual address)
    pub event_ref: [u8; 32],
}

// ============================================================================
// GOVERNANCE PARAMETERS
// ============================================================================

/// Create proposal parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CreateProposalParams {
    /// Unique proposal ID (hash of title + nonce)
    pub proposal_id: [u8; 32],
    /// Title hash (full title in memo)
    pub title_hash: [u8; 32],
    /// Description hash (full description in memo)
    pub description_hash: [u8; 32],
    /// Number of voting options
    pub options_count: u8,
    /// Voting start time (unix timestamp)
    pub start_time: i64,
    /// Voting end time (unix timestamp)
    pub end_time: i64,
    /// Quorum required (in basis points, 10000 = 100%)
    pub quorum_bps: u16,
    /// Is sealed voting (commit-reveal)?
    pub is_sealed: bool,
    /// Is confidential voting (encrypted)?
    pub is_confidential: bool,
}

/// Cast vote parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CastVoteParams {
    /// Proposal ID being voted on
    pub proposal_id: [u8; 32],
    /// Vote choice (0-indexed option)
    pub choice: u8,
    /// Voting power (tokens)
    pub voting_power: u64,
    /// Merkle proof of token ownership (if using virtual accounts)
    pub ownership_proof: Option<Vec<[u8; 32]>>,
    /// Path in merkle tree
    pub proof_path: u32,
}

/// Cast sealed vote parameters (commit phase)
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CastSealedVoteParams {
    /// Proposal ID being voted on
    pub proposal_id: [u8; 32],
    /// Vote commitment = hash(choice || salt || voter)
    pub commitment: [u8; 32],
    /// Voting power being committed
    pub voting_power: u64,
}

/// Reveal vote parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct RevealVoteParams {
    /// Proposal ID
    pub proposal_id: [u8; 32],
    /// Original commitment
    pub commitment: [u8; 32],
    /// Revealed choice
    pub choice: u8,
    /// Salt used in commitment
    pub salt: [u8; 32],
}

/// Finalize proposal parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct FinalizeProposalParams {
    /// Proposal ID to finalize
    pub proposal_id: [u8; 32],
    /// Vote tally per option
    pub vote_tallies: Vec<u64>,
    /// Total votes cast
    pub total_votes: u64,
    /// Merkle root of all votes
    pub votes_root: [u8; 32],
}

/// Cancel proposal parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CancelProposalParams {
    /// Proposal ID to cancel
    pub proposal_id: [u8; 32],
    /// Reason hash (full reason in memo)
    pub reason_hash: [u8; 32],
}

// ============================================================================
// VIRTUAL PDA PARAMETERS
// ============================================================================

/// Create virtual token account parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CreateVirtualAccountParams {
    /// Mint pubkey
    pub mint: Pubkey,
    /// Initial amount (usually 0 or from airdrop)
    pub initial_amount: u64,
    /// Extension flags
    pub extensions: u8,
}

/// Virtual transfer parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct VirtualTransferParams {
    /// Source account leaf hash
    pub source_hash: [u8; 32],
    /// Destination owner
    pub destination: Pubkey,
    /// Amount to transfer
    pub amount: u64,
    /// Merkle proof of source ownership
    pub source_proof: Vec<[u8; 32]>,
    /// Path in merkle tree
    pub proof_path: u32,
}

/// Virtual delegate parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct VirtualDelegateParams {
    /// Account leaf hash
    pub account_hash: [u8; 32],
    /// Delegate pubkey
    pub delegate: Pubkey,
    /// Amount to delegate
    pub amount: u64,
    /// Merkle proof of ownership
    pub proof: Vec<[u8; 32]>,
    /// Path in merkle tree
    pub proof_path: u32,
}

// ============================================================================
// CONFIDENTIAL VOTING PARAMETERS
// ============================================================================

/// Confidential vote parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct ConfidentialVoteParams {
    /// Proposal ID
    pub proposal_id: [u8; 32],
    /// Encrypted vote (ElGamal ciphertext)
    pub encrypted_choice: [u8; 64],
    /// Encrypted voting power
    pub encrypted_power: [u8; 64],
    /// Zero-knowledge proof of valid vote
    pub zk_proof: [u8; 128],
}

/// Submit decryption share parameters
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct SubmitDecryptionShareParams {
    /// Proposal ID
    pub proposal_id: [u8; 32],
    /// Guardian index (0-based)
    pub guardian_index: u8,
    /// Decryption share
    pub share: [u8; 32],
    /// Proof of correct decryption
    pub proof: [u8; 64],
}

// ============================================================================
// CHRONICLE DATA PARAMETERS (Custom Memo - Larger than Solana Memo!)
// ============================================================================

/// Data type identifiers for Chronicle Data anchoring
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone, Copy, PartialEq, Eq)]
#[borsh(use_discriminant = true)]
#[repr(u8)]
pub enum DataType {
    /// Proposal full text (title + description)
    ProposalContent = 1,
    /// Vote comment/justification
    VoteComment = 2,
    /// Census/poll question and options
    CensusContent = 3,
    /// Member profile data
    MemberProfile = 4,
    /// Execution packet details
    ExecutionPacket = 5,
    /// DAO metadata (name, image, etc.)
    DaoMetadata = 6,
    /// Bounty details
    BountyContent = 7,
    /// Custom application data
    CustomData = 255,
}

/// Anchor data chunk parameters (up to 900 bytes per instruction!)
/// This beats Solana's memo program limit of ~566 bytes.
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct AnchorDataParams {
    /// Data type (for indexing)
    pub data_type: u8,
    /// Entity ID (proposal_id, vote_id, etc.) - 32 bytes
    pub entity_id: [u8; 32],
    /// Chunk index (0-based)
    pub chunk_index: u16,
    /// Total chunks (1 = single chunk, >1 = multi-chunk)
    pub chunk_count: u16,
    /// Full data hash (same across all chunks)
    pub full_hash: [u8; 32],
    /// Chunk data (up to 800 bytes per chunk)
    pub data: Vec<u8>,
}

/// Anchor data header for multi-chunk data
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct AnchorDataHeaderParams {
    /// Data type
    pub data_type: u8,
    /// Entity ID
    pub entity_id: [u8; 32],
    /// Total number of chunks
    pub chunk_count: u16,
    /// Total data size in bytes
    pub total_size: u32,
    /// Full data hash (SHA256)
    pub full_hash: [u8; 32],
    /// Timestamp
    pub timestamp: i64,
}

/// Create data anchor PDA parameters (for permanent storage)
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct CreateDataAnchorParams {
    /// Data type
    pub data_type: u8,
    /// Entity ID
    pub entity_id: [u8; 32],
    /// Initial data (can be extended with AppendData)
    pub data: Vec<u8>,
    /// Whether more data will be appended
    pub is_extendable: bool,
}

/// Append data to existing anchor
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct AppendDataParams {
    /// Data to append
    pub data: Vec<u8>,
    /// Whether this is the final chunk
    pub is_final: bool,
}

/// Helper functions for building instructions
impl ChronicleInstruction {
    /// Serialize an InitializeDao instruction
    pub fn init_dao(params: InitializeDaoParams) -> Vec<u8> {
        let mut data = vec![Self::InitializeDao as u8];
        data.extend(borsh::to_vec(&params).unwrap());
        data
    }
    
    /// Serialize a LogEvent instruction
    pub fn log_event(params: LogEventParams) -> Vec<u8> {
        let mut data = vec![Self::LogEvent as u8];
        data.extend(borsh::to_vec(&params).unwrap());
        data
    }
    
    /// Serialize an AnchorRoot instruction
    pub fn anchor_root(params: AnchorRootParams) -> Vec<u8> {
        let mut data = vec![Self::AnchorRoot as u8];
        data.extend(borsh::to_vec(&params).unwrap());
        data
    }
    
    /// Serialize a VerifyEvent instruction
    pub fn verify_event(params: VerifyEventParams) -> Vec<u8> {
        let mut data = vec![Self::VerifyEvent as u8];
        data.extend(borsh::to_vec(&params).unwrap());
        data
    }
    
    /// Serialize a CreateAnchor instruction
    pub fn create_anchor(params: CreateAnchorParams) -> Vec<u8> {
        let mut data = vec![Self::CreateAnchor as u8];
        data.extend(borsh::to_vec(&params).unwrap());
        data
    }
}

/// Memo format for Chronicle events
/// 
/// Format: CHR2:<version>:<chunk_index>/<chunk_count>:<base64_payload>
/// 
/// Examples:
/// - Single chunk: CHR2:1:0/1:eyJldmVudCI6InZvdGUiLCJjaG9pY2UiOjF9
/// - Multi chunk:  CHR2:1:0/3:... , CHR2:1:1/3:... , CHR2:1:2/3:...
pub mod memo_format {
    /// Current memo format version
    pub const VERSION: u8 = 2;
    
    /// Memo program ID
    pub const MEMO_PROGRAM_ID: &str = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
    
    /// Maximum bytes per memo instruction
    pub const MAX_MEMO_BYTES: usize = 566;
    
    /// Header size: "CHR2:1:000/000:" = 15 bytes
    pub const HEADER_SIZE: usize = 15;
    
    /// Maximum payload per chunk
    pub const MAX_PAYLOAD_PER_CHUNK: usize = MAX_MEMO_BYTES - HEADER_SIZE;
    
    /// Format a memo header
    pub fn format_header(chunk_index: u16, chunk_count: u16) -> String {
        format!("CHR2:{}:{:03}/{:03}:", VERSION, chunk_index, chunk_count)
    }
    
    /// Parse a memo header, returns (version, chunk_index, chunk_count)
    pub fn parse_header(memo: &str) -> Option<(u8, u16, u16)> {
        if !memo.starts_with("CHR2:") {
            return None;
        }
        
        let parts: Vec<&str> = memo.splitn(4, ':').collect();
        if parts.len() < 4 {
            return None;
        }
        
        let version: u8 = parts[1].parse().ok()?;
        let chunk_parts: Vec<&str> = parts[2].split('/').collect();
        if chunk_parts.len() != 2 {
            return None;
        }
        
        let chunk_index: u16 = chunk_parts[0].parse().ok()?;
        let chunk_count: u16 = chunk_parts[1].parse().ok()?;
        
        Some((version, chunk_index, chunk_count))
    }
}
