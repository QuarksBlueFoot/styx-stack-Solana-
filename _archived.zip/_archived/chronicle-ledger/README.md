# Chronicle Ledger Program

A pure Rust Solana program for ultra-low-cost immutable governance records using a "Virtual PDA" architecture.

## Overview

Chronicle Ledger achieves **99.7% cost reduction** compared to traditional on-chain governance by storing data in transaction memos instead of rent-paying PDAs, while maintaining full cryptographic verifiability via merkle trees.

### Cost Comparison

| Operation | Traditional (PDA) | Chronicle | Savings |
|-----------|-------------------|-----------|---------|
| Cast Vote | ~0.002 SOL | ~0.000006 SOL | 99.7% |
| 100K Votes | ~204 SOL | ~0.6 SOL | 99.7% |

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Virtual PDA Concept                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Traditional:   seeds → PDA Account (pays rent forever)    │
│                                                             │
│  Chronicle:     seeds → Virtual Address (computed only)     │
│                 Data stored in memo, verified via merkle    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Components

1. **DaoRegistry** - Minimal on-chain account (128 bytes) storing:
   - DAO identifier
   - Authority pubkey
   - Current merkle root
   - Event count

2. **Virtual Events** - Governance events stored in memos:
   - Proposals, Votes, Finalizations
   - Each has a deterministic "virtual address"
   - Included in merkle tree for verification

3. **Merkle Tree** - Cryptographic proof structure:
   - Leaves = hashed events
   - Root = commitment to all events
   - Proofs = verify any event's inclusion

## Instructions

| Instruction | Description | Cost |
|-------------|-------------|------|
| `InitializeDao` | Create DAO registry | ~0.001 SOL |
| `LogEvent` | Log event (memo verification) | ~0.000005 SOL |
| `AnchorRoot` | Commit new merkle root | ~0.000005 SOL |
| `VerifyEvent` | Verify merkle proof | ~0.000005 SOL |
| `CreateAnchor` | Optional event anchor | ~0.0007 SOL |
| `UpdateAuthority` | Change DAO authority | ~0.000005 SOL |

## Building

```bash
# Prerequisites: Rust, Solana CLI

# Build
cargo build-sbf

# Test
cargo test

# Deploy to devnet
solana program deploy target/deploy/chronicle_ledger.so \
  --program-id ChronLedger111111111111111111111111111111111 \
  --url devnet
```

## Memo Format (CHR2)

Events are encoded in the Chronicle Memo Format:

```
CHR2:<version>:<chunk_index>/<chunk_count>:<base64_payload>

Example (single chunk vote):
CHR2:1:0/1:eyJ0IjoidiIsInAiOiJBQkMxMjMiLCJjIjoxfQ
```

Payload types:
- `v` - Vote
- `sv` - Sealed vote
- `p` - Proposal
- `f` - Finalize
- `c` - Council change

## Merkle Verification

```rust
use chronicle_ledger::merkle::{verify_proof, hash_leaf};

// Verify a vote was recorded
let leaf = hash_leaf(&vote_data);
let valid = verify_proof(&leaf, &proof, path, &root);
```

## Why Pure Rust?

No Anchor framework means:
- **Smaller binary**: ~15KB vs 200KB+ (cheaper deploy)
- **Lower CU**: Direct syscalls, no macro overhead
- **Full control**: Custom serialization, optimized layout

## Security

- **Immutability**: Events cannot be modified on Solana
- **Non-repudiation**: All actions require wallet signatures
- **Verifiability**: Anyone can replay chain to verify state
- **Transparency**: Database is just a cache, chain is truth

## License

Apache-2.0
