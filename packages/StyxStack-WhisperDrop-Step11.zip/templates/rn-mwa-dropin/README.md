# RN + MWA Drop-in Template (Styx)

This is a minimal integration sketch for Solana Mobile Wallet Adapter style signing.

- Build with `@styx/tx-tooling`
- Send via `@styx/solana-mobile-dropin`
- Scan inbox via `@styx/onchain-messaging`
