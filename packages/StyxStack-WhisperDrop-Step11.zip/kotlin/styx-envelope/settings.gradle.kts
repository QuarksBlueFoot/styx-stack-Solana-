rootProject.name = "styx-envelope"
