# styx-android (optional)

This is an **optional** Kotlin module that helps Android teams integrate Styx concepts
(outbox, receipts, safe logging) into existing Artemis/Solana Mobile apps.

It is NOT a wallet and NOT an app. It is glue code and interfaces.

You can delete this folder if you're TS-only.
