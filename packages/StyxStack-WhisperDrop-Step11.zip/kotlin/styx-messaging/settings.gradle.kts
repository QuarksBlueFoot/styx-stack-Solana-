rootProject.name = "styx-messaging"
