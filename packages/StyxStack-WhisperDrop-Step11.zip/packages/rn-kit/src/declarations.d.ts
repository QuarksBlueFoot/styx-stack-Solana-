declare module "tweetnacl";
