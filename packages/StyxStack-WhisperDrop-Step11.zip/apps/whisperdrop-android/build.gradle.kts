plugins {
  // Empty root build; module manages plugins
}
