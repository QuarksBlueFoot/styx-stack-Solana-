package com.styx.whisperdrop.wd

enum class ClaimMethod {
  LITE,   // Step 5A
  ESCROW  // Step 5B
}
