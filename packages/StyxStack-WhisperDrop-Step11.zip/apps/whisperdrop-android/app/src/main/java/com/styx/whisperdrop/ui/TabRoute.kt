package com.styx.whisperdrop.ui
enum class TabRoute { CAMPAIGN, MERKLE, VERIFY, MEMO, INBOX, CLAIM, SETTINGS }
